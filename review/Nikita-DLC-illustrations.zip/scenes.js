const scenes = [
  {
    "number": 1,
    "title": "Уютная полка",
    "image": "frames/01.webp"
  },
  {
    "number": 2,
    "title": "Город вдали",
    "image": "frames/02.webp"
  },
  {
    "number": 3,
    "title": "Проспект из ящиков",
    "image": "frames/03.webp"
  },
  {
    "number": 4,
    "title": "Хороший район",
    "image": "frames/04.webp"
  },
  {
    "number": 5,
    "title": "Воздушное движение",
    "image": "frames/05.webp"
  },
  {
    "number": 6,
    "title": "Четыре буквы",
    "image": "frames/06.webp"
  },
  {
    "number": 7,
    "title": "Аварийный сигнал",
    "image": "frames/07.webp"
  },
  {
    "number": 8,
    "title": "Будильник",
    "image": "frames/08.webp"
  },
  {
    "number": 9,
    "title": "Доброе утро",
    "image": "frames/09.webp"
  },
  {
    "number": 10,
    "title": "Полки до потолка",
    "image": "frames/10.webp"
  },
  {
    "number": 11,
    "title": "Где рюкзак?",
    "image": "frames/11.webp"
  },
  {
    "number": 12,
    "title": "Проход освободился",
    "image": "frames/12.webp"
  },
  {
    "number": 13,
    "title": "Первый день",
    "image": "frames/13.webp"
  },
  {
    "number": 14,
    "title": "ЛЭТИ наяву",
    "image": "frames/14.webp"
  },
  {
    "number": 15,
    "title": "За поворотом",
    "image": "frames/15.webp"
  },
  {
    "number": 16,
    "title": "Что там звенит?",
    "image": "frames/16.webp"
  },
  {
    "number": 17,
    "title": "Целый набор",
    "image": "frames/17.webp"
  },
  {
    "number": 18,
    "title": "Первая искра",
    "image": "frames/18.webp"
  },
  {
    "number": 19,
    "title": "Как тебя зовут?",
    "image": "frames/19.webp"
  },
  {
    "number": 20,
    "title": "Гайка",
    "image": "frames/20.webp"
  },
  {
    "number": 21,
    "title": "Пора расходиться",
    "image": "frames/21.webp"
  },
  {
    "number": 22,
    "title": "На обратном пути",
    "image": "frames/22.webp"
  },
  {
    "number": 23,
    "title": "Даже если не соберёшь",
    "image": "frames/23.webp"
  },
  {
    "number": 24,
    "title": "Проект на сегодня",
    "image": "frames/24.webp"
  },
  {
    "number": 25,
    "title": "Вместо аудитории",
    "image": "frames/25.webp"
  },
  {
    "number": 26,
    "title": "Трудовик",
    "image": "frames/26.webp"
  },
  {
    "number": 27,
    "title": "Я одолжу",
    "image": "frames/27.webp"
  },
  {
    "number": 28,
    "title": "Окно",
    "image": "frames/28.webp"
  },
  {
    "number": 29,
    "title": "Упаковано",
    "image": "frames/29.webp"
  },
  {
    "number": 30,
    "title": "Через главный вход",
    "image": "frames/30.webp"
  },
  {
    "number": 31,
    "title": "Бабушки держат проход",
    "image": "frames/31.webp"
  },
  {
    "number": 32,
    "title": "Кошерное место",
    "image": "frames/32.webp"
  },
  {
    "number": 33,
    "title": "Своя мастерская",
    "image": "frames/33.webp"
  },
  {
    "number": 34,
    "title": "Что уже было",
    "image": "frames/34.webp"
  },
  {
    "number": 35,
    "title": "Крылья из полок",
    "image": "frames/35.webp"
  },
  {
    "number": 36,
    "title": "Готов к показу",
    "image": "frames/36.webp"
  },
  {
    "number": 37,
    "title": "Три стука",
    "image": "frames/37.webp"
  },
  {
    "number": 38,
    "title": "Снова ты",
    "image": "frames/38.webp"
  },
  {
    "number": 39,
    "title": "Проходи…",
    "image": "frames/39.webp"
  },
  {
    "number": 40,
    "title": "Внимательный осмотр",
    "image": "frames/40.webp"
  }
];
