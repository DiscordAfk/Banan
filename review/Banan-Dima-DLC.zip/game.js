const catalog = document.querySelector('#catalog');
const novel = document.querySelector('#novel');
const menu = document.querySelector('#game-menu');
const gameAccessForm = document.querySelector('#game-access-form');
const gameAccessInput = document.querySelector('#game-access-code');
const gameAccessStatus = document.querySelector('#game-access-status');
const gameAccessSubmit = gameAccessForm.querySelector('button');
const playButton = document.querySelector('#play');
const story = document.querySelector('#story');
const ending = document.querySelector('#ending');
const endingArt = document.querySelector('#ending-art');
const endingTitle = document.querySelector('#ending-title');
const endingNote = document.querySelector('#ending-note');
const sceneArt = document.querySelector('#scene-art');
const stormLight = document.querySelector('#storm-light');
const lunchScore = document.querySelector('#lunch-score');
const lunchCount = document.querySelector('#lunch-count');
const lunchNames = document.querySelector('#lunch-names');
const lunchHotspots = document.querySelector('#lunch-hotspots');
const lunchPokerSeats = document.querySelector('#lunch-poker-seats');
const lunchGlasses = document.querySelector('#lunch-glasses');
const sceneAudio = document.querySelector('#scene-audio');
const rewardAudio = document.querySelector('#reward-audio');
const doorNameplate = document.querySelector('#door-nameplate');
const scenePicture = document.querySelector('#story-picture');
const holdemPanel = document.querySelector('#holdem-panel');
const holdemBet = document.querySelector('#holdem-bet');
const routeCaption = document.querySelector('#route-caption');
const routeStep = document.querySelector('#route-step');
const shoppingLabels = document.querySelector('#shopping-labels');
const ozonNametags = document.querySelector('#ozon-nametags');
const phoneProjection = document.querySelector('#phone-projection');
const sceneTitle = document.querySelector('#scene-title');
const sceneLine = document.querySelector('#scene-line');
const sceneSpeaker = document.querySelector('#speaker');
const workCall = document.querySelector('#work-call');
const workCallMessages = workCall.querySelectorAll('[data-call-message]');
const workCallDesigner = document.querySelector('#work-call-designer');
const workCallProgrammer = document.querySelector('#work-call-programmer');
const workCallStreamLabel = document.querySelector('#work-call-stream-label');
const workCallLiveBadges = workCall.querySelectorAll('.work-call-live');
const choices = document.querySelector('#choices');
const continueButton = document.querySelector('#continue');
const sceneBackButtons = document.querySelectorAll('[data-scene-back]');
const backLink = document.querySelector('#game-back');
const gameLabel = novel.querySelector('#game-label');
const gameMapLink = novel.querySelector('.game-map-link');
const novelTabs = novel.querySelector('#novel-tabs');
const allScenesTab = document.querySelector('#all-scenes-tab');
const allScenesPanel = document.querySelector('#all-scenes-panel');
const sceneGalleryTemplate = document.querySelector('#scene-gallery-template');
const achievementsPanel = document.querySelector('#achievements-panel');
const achievementsTab = document.querySelector('#achievements-tab');
const dlcPanel = document.querySelector('#dlc-panel');
const dlcTab = document.querySelector('#dlc-tab');
const dlcList = document.querySelector('#dlc-list');
const dlcCardTemplate = document.querySelector('#dlc-card-template');
const dlcMenuPanel = document.querySelector('#dlc-menu-panel');
const dlcOverview = document.querySelector('#dlc-overview');
const dlcMenuTitle = document.querySelector('#dlc-menu-title');
const dlcMenuCover = document.querySelector('#dlc-menu-cover');
const playDlcButton = document.querySelector('#play-dlc');
const dlcRoadmap = document.querySelector('#dlc-roadmap');
const dlcAchievementList = document.querySelector('#dlc-achievement-list');
const dlcAchievementProgress = document.querySelector('#dlc-achievement-progress');
const dlcAchievementsEmpty = document.querySelector('#dlc-achievements-empty');
const dlcCheckpoints = new Set(downloadableStories
  .flatMap(({ roadmap = [] }) => roadmap.slice(1))
  .map(({ scene }) => scene)
  .filter(Boolean));
const dlcSections = {
  achievements: { tab: document.querySelector('#dlc-achievements-tab'), panel: document.querySelector('#dlc-achievements-panel') },
  'story-map': { tab: document.querySelector('#dlc-story-map-tab'), panel: document.querySelector('#dlc-story-map-panel') },
  'all-scenes': { tab: document.querySelector('#dlc-all-scenes-tab'), panel: document.querySelector('#dlc-all-scenes-panel') },
};
const charactersPanel = document.querySelector('#characters-panel');
const charactersTab = document.querySelector('#characters-tab');
const characterList = document.querySelector('#character-list');
const characterStoryPanel = document.querySelector('#character-story-panel');
const characterStoryTitle = document.querySelector('#character-story-title');
const characterStoryPortrait = document.querySelector('#character-story-portrait');
const characterStoryQualifier = document.querySelector('#character-story-qualifier');
const characterStoryEpisodes = document.querySelector('#character-story-episodes');
const characterStoryEmpty = document.querySelector('#character-story-empty');
const characterStoryPlay = document.querySelector('#character-story-play');
const endingMapLink = document.querySelector('#ending-map-link');
const characterProfile = document.querySelector('#character-profile');
const characterProfileBody = document.querySelector('#character-profile-body');
const characterRevealAudio = document.querySelector('#character-reveal-audio');
const storyMapPanel = document.querySelector('#story-map-panel');
const storyMapTab = document.querySelector('#story-map-tab');
const storyStarts = new Map(Array.from(storyMapPanel.querySelectorAll('[data-story-start]'),
  (button) => [button.dataset.storyStart, button]));
const resumeButton = document.querySelector('#resume-decision');
const resumeDetail = document.querySelector('#resume-detail');
const storyEndingBranches = storyMapPanel.querySelectorAll('[data-story-endings]');
const storyAchievementBranches = storyMapPanel.querySelectorAll('[data-story-achievements]');
const endingPreview = document.querySelector('#ending-preview');
const endingPreviewTitle = document.querySelector('#ending-preview-title');
const endingPreviewArt = document.querySelector('#ending-preview-art');
const settingsDialog = document.querySelector('#settings');
const developerTools = document.querySelector('#developer-tools');
const developerAccessForm = document.querySelector('#developer-access-form');
const developerCode = document.querySelector('#developer-code');
const developerCodeStatus = document.querySelector('#developer-code-status');
const developerActions = document.querySelector('#developer-actions');
const developerUnlock = document.querySelector('#developer-unlock');
const developerUnlockCharacters = document.querySelector('#developer-unlock-characters');
const developerSaveAchievements = document.querySelector('#developer-save-achievements');
const muteSound = document.querySelector('#mute-sound');
const requestProgressReset = document.querySelector('#request-progress-reset');
const progressResetConfirmation = document.querySelector('#progress-reset-confirmation');
const cancelProgressReset = document.querySelector('#cancel-progress-reset');
const achievementList = document.querySelector('#achievement-list');
const achievementProgress = document.querySelector('#achievement-progress');
const dlcAchievementGroups = document.querySelector('#dlc-achievement-groups');
const dlcAchievementGroupTemplate = document.querySelector('#dlc-achievement-group-template');
const achievementAward = document.querySelector('#achievement-award');
const endingAward = document.querySelector('#ending-award');
const gameOverTitle = document.querySelector('#game-over-title');
const dianaChat = document.querySelector('#diana-chat');
const dianaChatName = document.querySelector('#diana-chat-name');
const ozonChat = document.querySelector('#ozon-chat');
const ozonChatName = document.querySelector('#ozon-chat-name');
const chatMessages = document.querySelector('#chat-messages');
const phoneScoreboard = document.querySelector('#phone-scoreboard');
const phoneRoundLabel = document.querySelector('#phone-round-label');
const phoneScore = document.querySelector('#phone-score');
const answerFeedback = document.querySelector('#answer-feedback');

const dialogue = document.querySelector('#dialogue');
const thoughtBubble = document.querySelector('#thought-bubble');
const thoughtText = document.querySelector('#thought-text');
const thoughtMoney = document.querySelector('#thought-money');
const fingerMovement = document.querySelector('#finger-movement');
const intertitle = document.querySelector('#intertitle');
const intertitleArt = document.querySelector('#intertitle-art');
const intertitleNext = document.querySelector('#intertitle-next');
const intertitleSound = document.querySelector('#intertitle-sound');
const intertitleAudio = document.querySelector('#intertitle-audio');
const intertitleStatus = document.querySelector('#intertitle-status');
const blenderLaunch = document.querySelector('#blender-launch');
const blenderWorkspace = document.querySelector('#blender-workspace');
const blenderChat = document.querySelector('#blender-chat');
const blenderDraft = document.querySelector('#blender-draft');
const blenderDimaScreen = document.querySelector('#blender-dima-screen');
const blenderModelProgress = document.querySelector('#blender-model-progress');
const blenderFiles = document.querySelector('#blender-files');
const blenderProjectLabels = document.querySelector('#blender-project-labels');
const dioramaCheck = document.querySelector('#blender-diorama-check');
const dioramaPhoto = document.querySelector('#diorama-photo');
const dioramaSelection = document.querySelector('#diorama-selection');
const dioramaCubes = document.querySelector('#diorama-cubes');
const dioramaFirstCube = document.querySelector('#diorama-first-cube');
const dioramaTitle = document.querySelector('#diorama-screen-title');
const dioramaNote = document.querySelector('#diorama-screen-note');
const nightClockCard = document.querySelector('#night-clock-card');
const nightTimeBadge = document.querySelector('#night-time-badge');
const nightPhoneNote = document.querySelector('#night-phone-note');
const churchTelegramExamples = document.querySelector('#church-telegram-examples');
const churchFallLettering = document.querySelector('#church-fall-lettering');
const nightPhoneSource = document.querySelector('#night-phone-source');
const nightPhoneText = document.querySelector('#night-phone-text');
const nightPhoneSecond = document.querySelector('#night-phone-second');
const sleepBubble = document.querySelector('#sleep-bubble');
const nightDiscord = document.querySelector('#night-discord');
const nightDiscordPlayers = document.querySelector('#night-discord-players');
const nightDiscordShots = document.querySelector('#night-discord-shots');
const nightVideoScroll = document.querySelector('#night-video-scroll');
const nightCharacterSwitch = document.querySelector('#night-character-switch');
const nightGameName = document.querySelector('#night-game-name');
const nightVoice = document.querySelector('#night-voice');
const nightVoiceGrid = document.querySelector('#night-voice-grid');
const nightVoiceCount = document.querySelector('#night-voice-count');
const nightReaction = document.querySelector('#night-reaction');
const historyClassroomPlates = document.querySelector('#history-classroom-plates');
const historyInformaticsPlate = document.querySelector('#history-informatics-plate');
const historyLockscreen = document.querySelector('#history-lockscreen');
const historyDoorSlam = document.querySelector('#history-door-slam');
const endingContinue = document.querySelector('#ending-continue');
const storyNightBranch = document.querySelector('#story-night-branch');

const sceneTimers = [];
let voiceSequence;
let voiceSequenceFrame;
const nightJoinTimes = [180, 860, 1540, 2220];
const nightLeaveTimes = [180, 880, 1580, 2280, 2980];
const nightPhoneMessages = {
  'two-chats': ['Telegram · Диана', 'Открыт чат'],
  sent: ['Telegram · Диана', 'Привет, спишь?'],
  news: ['Новости Петербурга', 'Объявлена опасность БПЛА'],
  received: ['Telegram · Серёжа', 'Привет, спишь?'],
  one: ['Экран блокировки', '1 уведомление'],
  letter: ['Входящий звонок', 'Д…'],
  denis: ['Вызов принят', 'Денис'],
  'sleep-call': ['Входящий звонок', 'Денис'],
  'sleep-missed': ['Пропущенный звонок', 'Денис'],
  'church-telegram': ['Жорно', '1 участник · 3000 фотографий'],
  'church-steam': ['долдол сейчас играет', 'Counter-Strike 2'],
  'sleep-warning': ['Староста', 'Если сегодня опять пропустишь, то тебя отчислят'],
};
const lectureFrames = [
  ['45 минут', 'night-sleep-lecture-study-middle', 'Серёжа пододвигает к Диане конспект с рисунком на полях.'],
  ['80 минут', 'night-sleep-lecture-study-late', 'Серёжа и Диана улыбаются, сравнивая записи. Солнечный свет уже на другой стороне парты.'],
];

const gameStoragePrefix = 'minigames.seryozha.';
const gameAccessHash = '0184f0b4a19a10ce2677bb58b7ad872e316b1a2eccc99736284ea0b4ab529382';
const developerCodeHash = '4bcfec3e4eb774ccde4285b4ffbc126cf072f01c9dd64f0ca3e24de83816f868';
const gameAccessKey = `${gameStoragePrefix}access.${gameAccessHash}`;
const endingsStorageKey = `${gameStoragePrefix}endings`;
const decisionStorageKey = `${gameStoragePrefix}last-decision`;
const storyStartStoragePrefix = `${gameStoragePrefix}story-start.`;
const dlcStoragePrefix = `${gameStoragePrefix}dlc.`;
const characterStoragePrefix = `${gameStoragePrefix}character.`;
const dianaAliasStorageKey = `${characterStoragePrefix}diana-alias`;
const mutedSoundStorageKey = 'minigames.settings.mute-sound';
const progressResetStorageKey = 'minigames.settings.progress-reset';
const discoveredCharacters = new Set();
const previewedCharacters = new Set();
let dianaAlias;
const profileQueue = [];
let activeProfile;
let morningProfileTimer;
const unlockedEndings = new Set();
const unlockedAchievements = new Set();
const visitedStoryStarts = new Set();
const unlockedDlc = new Set();
const hiddenRewardTitle = '????????????';
let phoneQuiz;
let lastDecision;
let pendingStoryStart;
let activeCharacterStory;
let gameAccessGranted = false;
let developerMode = false;
try {
  gameAccessGranted = sessionStorage.getItem(gameAccessKey) === '1';
} catch {
  // The game can still be unlocked until the page reloads.
}

function applySoundSetting(muted) {
  muteSound.checked = muted;
  for (const audio of document.querySelectorAll('audio')) audio.muted = muted;
}

function showProgressResetConfirmation(visible) {
  progressResetConfirmation.hidden = !visible;
  requestProgressReset.setAttribute('aria-expanded', String(visible));
}

function restartAtCatalog() {
  const url = new URL(window.location.href);
  url.hash = '';
  window.history.replaceState(null, '', url);
  window.location.reload();
}

function resetProgress() {
  try {
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith(gameStoragePrefix) && !key.startsWith(dlcStoragePrefix)) localStorage.removeItem(key);
    }
    localStorage.setItem(progressResetStorageKey, String(Date.now()));
  } catch {
    // Reloading still clears in-memory progress when storage is unavailable.
  }
  restartAtCatalog();
}

function hasGameAccess() {
  return gameAccessGranted || developerMode;
}

function allBranchesOpen() {
  return developerMode && developerUnlock.checked;
}

const characterStoryHash = (id) => id === 'seryozha' ? '#story-map' : `#character-story/${id}`;

function canOpenCharacterStory(id) {
  return Object.hasOwn(characterStories, id) && (id === 'seryozha' || discoveredCharacters.has(id));
}

function playCharacterStory(id, chapter = 0) {
  if (!canOpenCharacterStory(id)) return;
  if (id === 'seryozha') {
    window.location.hash = '#seryozha';
    return;
  }
  const { episodes } = characterStories[id];
  if (!episodes.length) {
    window.location.hash = characterStoryHash(id);
    return;
  }
  if (!episodes[chapter]) return;

  const nextByScene = new Map();
  for (const [index, [, first, last]] of episodes.entries()) {
    let key = first;
    while (scenes[key] && !nextByScene.has(key)) {
      nextByScene.set(key, key === last ? episodes[index + 1]?.[1] : scenes[key].next);
      if (key === last) break;
      key = scenes[key].next;
    }
  }
  openStoryAt({ scene: episodes[chapter][1], characterStory: { id, nextByScene } });
}

function renderCharacterStoryMap(id) {
  const route = characterStories[id];
  characterStoryTitle.textContent = `Сюжет ${route.name}`;
  characterStoryQualifier.hidden = !route.qualifier;
  characterStoryQualifier.textContent = route.qualifier ?? '';
  characterStoryPortrait.src = artPath(characters[id].art);
  const hasEpisodes = route.episodes.length > 0;
  characterStoryPlay.hidden = !hasEpisodes;
  characterStoryEpisodes.hidden = !hasEpisodes;
  characterStoryEmpty.hidden = hasEpisodes;
  characterStoryPlay.onclick = () => playCharacterStory(id);
  characterStoryEpisodes.replaceChildren(...route.episodes.map(([title, first, , artwork], index) => {
    const episode = document.createElement('li');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'story-point story-point-art character-story-point';
    button.addEventListener('click', () => playCharacterStory(id, index));
    const art = document.createElement('img');
    art.alt = '';
    art.loading = 'lazy';
    art.src = artPath(artwork ?? scenes[first].art ?? characters[id].art);
    const label = document.createElement('strong');
    label.textContent = title;
    button.append(art, label);
    episode.append(button);
    return episode;
  }));
}

function canActivateDlc(character) {
  return allBranchesOpen() || discoveredCharacters.has(character);
}

function hasDlcAccess(character) {
  if (allBranchesOpen()) return true;
  if (!canActivateDlc(character)) return false;
  if (unlockedDlc.has(character)) return true;
  try {
    return localStorage.getItem(dlcStoragePrefix + character) === '1';
  } catch {
    return false;
  }
}

async function matchesAccessCode(code, hash) {
  const bytes = new TextEncoder().encode(code.trim().toUpperCase());
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('') === hash;
}

gameAccessInput.addEventListener('input', () => {
  gameAccessInput.removeAttribute('aria-invalid');
  gameAccessStatus.textContent = '';
});

gameAccessForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (gameAccessSubmit.disabled) return;
  gameAccessSubmit.disabled = true;
  gameAccessInput.readOnly = true;
  try {
    if (!await matchesAccessCode(gameAccessInput.value, gameAccessHash)) {
      gameAccessInput.setAttribute('aria-invalid', 'true');
      gameAccessStatus.textContent = 'Неверный код доступа.';
      gameAccessInput.focus();
      return;
    }
  } catch {
    gameAccessStatus.textContent = 'Проверка кода недоступна. Открой сайт через HTTPS или localhost.';
    return;
  } finally {
    gameAccessSubmit.disabled = false;
    gameAccessInput.readOnly = false;
  }

  gameAccessGranted = true;
  try {
    sessionStorage.setItem(gameAccessKey, '1');
  } catch {
    // Access remains enabled until the page reloads.
  }
  gameAccessForm.reset();
  if (window.location.hash === '#seryozha') {
    syncRoute();
    playButton.focus();
  }
});

function dlcMenuHash(character, section) {
  return section ? `#dlc/${character}/${section}` : `#dlc/${character}`;
}

function renderDlc(selectedDlc) {
  const entries = selectedDlc ? [selectedDlc] : downloadableStories;
  dlcList.replaceChildren(...entries.map(({ character, title, codeHash, roadmap }) => {
    const firstScene = roadmap?.[0]?.scene;
    const card = dlcCardTemplate.content.firstElementChild.cloneNode(true);
    card.querySelector('img').src = artPath(characters[character].art);
    card.querySelector('h3').textContent = title;
    card.querySelector('.dlc-character').textContent = characters[character].name;

    const form = card.querySelector('form');
    const input = form.elements.namedItem('code');
    const submit = form.querySelector('button');
    const feedback = form.querySelector('[role="status"]');
    const play = card.querySelector('.dlc-play');
    const details = card.querySelector('details');
    const lockedNotice = card.querySelector('.dlc-locked');
    const canActivate = canActivateDlc(character);
    const hasAccess = hasDlcAccess(character);
    lockedNotice.hidden = canActivate;
    form.hidden = !canActivate || hasAccess;
    play.hidden = !hasAccess || !firstScene;
    details.hidden = !hasAccess || Boolean(firstScene);
    if (firstScene) play.href = dlcMenuHash(character);
    if (!canActivate || hasAccess) return card;

    input.addEventListener('input', () => {
      input.removeAttribute('aria-invalid');
      feedback.textContent = '';
    });
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (submit.disabled || !canActivateDlc(character)) return;
      submit.disabled = true;
      try {
        if (!await matchesAccessCode(input.value, codeHash)) {
          input.setAttribute('aria-invalid', 'true');
          feedback.textContent = 'Неверный код доступа.';
          input.focus();
          return;
        }
      } catch {
        feedback.textContent = 'Проверка кода недоступна. Попробуй открыть сайт через HTTPS или localhost.';
        return;
      } finally {
        submit.disabled = false;
      }

      if (!canActivateDlc(character)) return;
      unlockedDlc.add(character);
      try {
        localStorage.setItem(dlcStoragePrefix + character, '1');
      } catch {
        // Access lasts for this visit if storage is unavailable.
      }
      if (window.location.hash === dlcMenuHash(character)) {
        syncRoute(true);
        return;
      }
      form.reset();
      form.hidden = true;
      if (firstScene) {
        play.hidden = false;
        play.focus();
      } else {
        details.hidden = false;
        details.open = true;
        details.querySelector('summary').focus();
      }
    });
    return card;
  }));
}

function playDlc(dlc, scene) {
  if (!scene || !hasDlcAccess(dlc.character)) return;
  openStoryAt(dlcStoryStart(dlc, scene));
}

function dlcStoryStart(dlc, scene) {
  return {
    scene, characterStory: { id: dlc.character, dlc: dlc.title, achievements: dlc.achievements ?? [] },
  };
}

function renderDlcMenu(dlc, section) {
  dlcOverview.hidden = Boolean(section);
  if (!section) {
    const firstScene = dlc.roadmap[0].scene;
    dlcMenuTitle.textContent = dlc.title;
    dlcMenuCover.src = artPath(scenes[firstScene].art);
    playDlcButton.onclick = () => playDlc(dlc, firstScene);
  }
  for (const [name, { tab, panel }] of Object.entries(dlcSections)) {
    tab.href = dlcMenuHash(dlc.character, name);
    tab.hidden = name === 'all-scenes' && !developerMode;
    panel.hidden = name !== section;
    if (name === section) tab.setAttribute('aria-current', 'page');
    else tab.removeAttribute('aria-current');
  }
  if (section === 'achievements') {
    const results = dlc.achievements ?? [];
    renderAchievementCards(results, dlcAchievementList, dlcAchievementProgress);
    dlcAchievementProgress.hidden = !results.length;
    dlcAchievementsEmpty.hidden = Boolean(results.length);
  }
  if (section === 'story-map') renderDlcRoadmap(dlc);
  if (section === 'all-scenes') renderSceneGallery(dlcSections[section].panel, dlc);
}

function renderDlcRoadmap(dlc) {
  readAchievements(dlc.achievements ?? []);
  const root = dlc.roadmap.reduceRight((next, { scene, reward, reachedBy }, index) => {
    const item = document.createElement('li');
    const node = document.createElement('div');
    node.className = 'story-tree-node';
    const button = document.createElement('button');
    button.className = 'story-point';
    button.classList.toggle('story-point-fork', index === 0);
    button.type = 'button';
    const data = scenes[scene];
    if (data?.art) {
      button.classList.add('story-point-art');
      const illustration = document.createElement('img');
      illustration.src = artPath(data.art);
      illustration.alt = '';
      illustration.loading = 'lazy';
      button.append(illustration);
    }
    const title = document.createElement('strong');
    title.textContent = data?.title ?? 'В разработке';
    button.append(title);
    button.disabled = !data || (index > 0 && !isDlcCheckpointUnlocked(scene, reachedBy));
    if (data && index > 0) button.dataset.dlcCheckpoint = scene;
    if (reachedBy) button.dataset.reachedBy = reachedBy;
    button.addEventListener('click', () => playDlc(dlc, scene));
    node.append(button);
    item.append(node);
    if (next || reward) {
      const branches = document.createElement('ol');
      branches.className = 'story-branches';
      if (next) branches.append(next);
      if (reward) {
        const leaf = document.createElement('li');
        leaf.className = 'story-endings';
        const card = rewardCard(reward, allBranchesOpen() || unlockedAchievements.has(reward.id), 'h4', true);
        card.classList.add('story-tree-node');
        leaf.append(card);
        branches.append(leaf);
      }
      item.append(branches);
    }
    return item;
  }, null);
  dlcRoadmap.replaceChildren(...(root ? [root] : []));
}

function isDlcCheckpointUnlocked(scene, reachedBy) {
  return isStoryStartUnlocked(scene) || unlockedAchievements.has(reachedBy);
}

function rememberStoryStart(scene) {
  if (developerMode) return;
  if (scene === 'morning' || visitedStoryStarts.has(scene)) return;
  if (!storyStarts.has(scene) && !dlcCheckpoints.has(scene)) return;
  visitedStoryStarts.add(scene);
  try {
    localStorage.setItem(storyStartStoragePrefix + scene, '1');
  } catch {
    // Visited points stay available during the current visit.
  }
}

function isStoryStartUnlocked(scene) {
  if (allBranchesOpen() || scene === 'morning' || visitedStoryStarts.has(scene)) return true;
  if (scene === 'night-choice' && unlockedEndings.has('first-step')) return true;
  try {
    return localStorage.getItem(storyStartStoragePrefix + scene) === '1';
  } catch {
    return false;
  }
}

function renderStoryStarts() {
  for (const [scene, button] of storyStarts) button.disabled = !isStoryStartUnlocked(scene);
  for (const button of dlcRoadmap.querySelectorAll('[data-dlc-checkpoint]')) {
    button.disabled = !isDlcCheckpointUnlocked(button.dataset.dlcCheckpoint, button.dataset.reachedBy);
  }
}

function rememberDecision(scene, phone, lunch) {
  if (developerMode) return;
  lastDecision = phone ? { scene, phone: { index: phone.index, correct: phone.correct } } : { scene };
  if (lunch) lastDecision.lunch = lunch;
  try {
    localStorage.setItem(decisionStorageKey, JSON.stringify(lastDecision));
  } catch {
    // The last decision still works within the current visit.
  }
}

function renderLastDecision() {
  try {
    const saved = JSON.parse(localStorage.getItem(decisionStorageKey) ?? 'null');
    if (saved && Object.hasOwn(scenes, saved.scene)) {
      const { scene, phone } = saved;
      if (scenes[scene].cafeteria || scenes[scene].lunchScore) {
        lastDecision = { scene, lunch: restoreLunchProgress(saved.lunch) };
      } else if (scenes[scene].options) {
        lastDecision = { scene };
      } else if (scenes[scene].quiz && phone &&
        Number.isInteger(phone.index) && phone.index >= 0 && phone.index < phoneRounds.length &&
        Number.isInteger(phone.correct) && phone.correct >= 0 && phone.correct <= phone.index) {
        lastDecision = { scene, phone };
      }
    }
  } catch {
    // A blocked or invalid save can be replaced by playing to a decision.
  }

  if (lastDecision) rememberStoryStart(lastDecision.phone ? 'home-phone' : lastDecision.scene);
  resumeButton.disabled = !lastDecision;
  if (!lastDecision) {
    resumeDetail.textContent = 'Появится после первой развилки.';
  } else if (lastDecision.phone) {
    resumeDetail.textContent = `Телефон · раунд ${lastDecision.phone.index + 1} из ${phoneRounds.length}`;
  } else {
    resumeDetail.textContent = scenes[lastDecision.scene].title;
  }
}

function openStoryAt(start) {
  if (!hasGameAccess()) return;
  pendingStoryStart = start;
  if (window.location.hash === '#seryozha') syncRoute();
  else window.location.hash = '#seryozha';
}

function readEndings() {
  try {
    const saved = JSON.parse(localStorage.getItem(endingsStorageKey) ?? '[]');
    if (!Array.isArray(saved)) return;
    for (const { id } of endings) {
      if (saved.includes(id)) unlockedEndings.add(id);
    }
  } catch {
    // A blocked or invalid browser save still allows progress in the current visit.
  }
}

function unlockEnding(id) {
  if (developerMode) return;
  readEndings();
  unlockedEndings.add(id);
  try {
    localStorage.setItem(endingsStorageKey, JSON.stringify([...unlockedEndings]));
  } catch {
    // Keep the unlock available in this visit if the browser blocks writes.
  }
}

function unlockAchievement(id) {
  if (unlockedAchievements.has(id)) return false;
  unlockedAchievements.add(id);
  try {
    const key = gameStoragePrefix + id;
    if (localStorage.getItem(key) === '1') return false;
    localStorage.setItem(key, '1');
  } catch {
    // The achievement remains unlocked in the current visit.
  }
  return true;
}

function rewardLabel(result) {
  if (result.number === undefined) return 'Достижение';
  const type = result.intermediate ? 'Промежуточная концовка' : 'Концовка';
  return `${type} #${result.number}`;
}

function rewardCard(result, unlocked, headingTag, preview = false) {
  const card = document.createElement('article');
  card.className = 'result-card';
  const thumbnail = document.createElement('div');
  const isEnding = result.number !== undefined;
  thumbnail.className = isEnding || result.crossed || result.fullArt ? 'result-art' : 'result-art result-icon';
  if (result.fullArt) thumbnail.classList.add('result-contain');
  if (unlocked) {
    if (result.crossed) thumbnail.classList.add('result-crossed');
    const img = document.createElement('img');
    img.src = artPath(result.art);
    img.alt = '';
    thumbnail.append(img);
  } else {
    thumbnail.classList.add('result-locked', `silhouette-${result.id}`);
    thumbnail.setAttribute('aria-label', isEnding ? 'Концовка ещё не открыта' : 'Достижение ещё не открыто');
    thumbnail.setAttribute('role', 'img');
  }
  const info = document.createElement('div');
  info.className = 'result-info';
  const label = document.createElement('p');
  label.className = 'genre';
  label.textContent = rewardLabel(result);
  const title = document.createElement(headingTag);
  title.textContent = unlocked ? result.title : hiddenRewardTitle;
  info.append(label, title);
  card.append(thumbnail, info);
  if (unlocked && preview) {
    const trigger = document.createElement('button');
    trigger.className = 'result-preview-trigger';
    trigger.type = 'button';
    trigger.setAttribute('aria-label', `Увеличить изображение: ${rewardLabel(result).toLowerCase()} «${result.title}»`);
    trigger.setAttribute('aria-haspopup', 'dialog');
    trigger.addEventListener('click', () => showEndingPreview(result));
    card.append(trigger);
  }
  return card;
}

function readAchievements(results = achievements) {
  try {
    for (const { id } of results) {
      if (localStorage.getItem(gameStoragePrefix + id) === '1') unlockedAchievements.add(id);
    }
  } catch {
    // In-memory progress is available when storage is blocked.
  }
}

function renderAchievements() {
  readEndings();
  renderAchievementCards(achievements, achievementList, achievementProgress, endings);
  dlcAchievementGroups.replaceChildren();
  for (const { title, achievements: results } of downloadableStories) {
    if (!results?.length) continue;
    const group = dlcAchievementGroupTemplate.content.firstElementChild.cloneNode(true);
    group.querySelector('h3').textContent = title;
    renderAchievementCards(results, group.querySelector('.achievement-list'), group.querySelector('p'));
    dlcAchievementGroups.append(group);
  }
}

function renderAchievementCards(results, list, progress, endingResults = []) {
  readAchievements(results);
  const unlocked = results.filter(({ id }) => unlockedAchievements.has(id)).length;
  const ended = endingResults.filter(({ id }) => unlockedEndings.has(id)).length;
  progress.textContent = `Открыто ${ended + unlocked} из ${endingResults.length + results.length}`;
  list.replaceChildren(
    ...endingResults.map((result) => rewardCard(result, unlockedEndings.has(result.id), 'h4')),
    ...results.map((result) => rewardCard(result, unlockedAchievements.has(result.id), 'h4')),
  );
}

function renderAchievementAward(id, container = scenePicture) {
  const results = activeCharacterStory?.achievements ?? achievements;
  const achievement = results.find((result) => result.id === id);
  achievementAward.hidden = !achievement?.showOnScene;
  if (!achievement) return false;

  const recordsProgress = (!activeCharacterStory || Boolean(activeCharacterStory.dlc))
    && (!developerMode || developerSaveAchievements.checked);
  if (achievement.showOnScene) {
    const card = rewardCard(achievement, true, 'h2');
    const label = recordsProgress ? 'Достижение открыто' : 'Предпросмотр достижения';
    if (!recordsProgress) card.querySelector('.genre').textContent = label;
    achievementAward.setAttribute('aria-label', label);
    achievementAward.replaceChildren(card);
    if (achievementAward.parentElement !== container) container.append(achievementAward);
  }
  return recordsProgress && unlockAchievement(achievement.id);
}

function showEndingPreview(result) {
  endingPreviewTitle.textContent = `${rewardLabel(result)} «${result.title}»`;
  endingPreviewArt.src = artPath(result.art);
  endingPreviewArt.alt = scenes[result.art]?.alt ?? result.title;
  endingPreview.showModal();
}

function renderStoryRewards() {
  readEndings();
  readAchievements();
  storyNightBranch.hidden = !allBranchesOpen() && !unlockedEndings.has('first-step');
  renderStoryStarts();
  for (const branch of [...storyEndingBranches, ...storyAchievementBranches]) {
    const achievementScenes = branch.dataset.storyAchievements?.split(' ');
    const leaves = achievementScenes
      ? achievementScenes.map((key) => achievements.find(({ id }) => id === scenes[key]?.achievement)).filter(Boolean)
      : endings.filter((result) => result.branch === branch.dataset.storyEndings);
    const unlocked = achievementScenes ? unlockedAchievements : unlockedEndings;
    branch.replaceChildren(...leaves.map((result) => {
      const leaf = document.createElement('li');
      const card = rewardCard(result, allBranchesOpen() || unlocked.has(result.id), 'h4', true);
      card.classList.add('story-tree-node');
      leaf.append(card);
      if (result.id === 'first-step') leaf.append(storyNightBranch);
      return leaf;
    }));
  }
}

function renderDianaChat(reply) {
  rememberDianaAlias('chat');
  const name = dianaContactName();
  dianaChatName.textContent = name;
  const makeMessage = (text, fromDiana = false) => {
    const message = document.createElement('li');
    message.className = fromDiana ? 'chat-incoming' : 'chat-outgoing';
    message.textContent = text;
    return message;
  };
  const heart = makeMessage('❤️', true);
  heart.setAttribute('aria-label', `${name} отправила красное сердце`);
  chatMessages.replaceChildren(...phoneRounds.map(({ message, unknownMessage }) => makeMessage(
    discoveredCharacters.has('diana') ? message : unknownMessage ?? message,
  )), heart);
  if (reply) {
    const message = makeMessage('', true);
    const quote = document.createElement('blockquote');
    quote.textContent = phoneRounds.at(-1).message;
    const answer = document.createElement('p');
    answer.textContent = reply;
    message.replaceChildren(quote, answer);
    chatMessages.append(message);
  }
}

function addChoice(label, onClick) {
  const button = document.createElement('button');
  button.className = 'choice';
  button.type = 'button';
  button.textContent = label;
  button.addEventListener('click', () => onClick(button));
  choices.append(button);
}

function updatePhoneScore() {
  phoneScore.textContent = `${phoneQuiz.correct}/${phoneRounds.length} правильных выборов`;
}

function renderPhoneRound() {
  rememberDianaAlias('choice');
  activePosition.phone = { index: phoneQuiz.index, correct: phoneQuiz.correct };
  rememberDecision('phone-quiz', phoneQuiz);
  updateSceneBack();
  const round = phoneRounds[phoneQuiz.index];
  phoneRoundLabel.textContent = `Раунд ${phoneQuiz.index + 1} из ${phoneRounds.length}`;
  phoneRoundLabel.hidden = false;
  updatePhoneScore();
  choices.replaceChildren();
  phoneQuiz.answered = false;
  answerFeedback.hidden = true;
  answerFeedback.textContent = '';
  continueButton.hidden = true;
  addChoice(discoveredCharacters.has('diana') ? round.label : round.unknownLabel, (button) => answerPhoneRound(button, true));
  addChoice(round.alternative, (button) => answerPhoneRound(button, false));
}

function answerPhoneRound(button, correct) {
  if (phoneQuiz.answered) return;
  phoneQuiz.answered = true;
  phoneQuiz.correct += Number(correct);
  updatePhoneScore();

  for (const choice of choices.children) choice.disabled = true;
  button.classList.add(correct ? 'choice-correct' : 'choice-incorrect');
  const icon = document.createElement('span');
  icon.className = 'choice-result-icon';
  icon.textContent = correct ? '✓' : '✕';
  icon.setAttribute('aria-hidden', 'true');
  button.append(icon);
  answerFeedback.textContent = correct ? 'Правильный выбор' : 'Неправильный выбор';
  answerFeedback.className = `answer-feedback ${correct ? 'feedback-correct' : 'feedback-incorrect'}`;
  answerFeedback.hidden = false;
  continueButton.textContent = phoneQuiz.index === phoneRounds.length - 1 ? 'Посмотреть результат' : 'Следующий раунд';
  continueButton.hidden = false;
  continueButton.focus();
}

function advancePhoneRound() {
  if (!phoneQuiz.answered) return;
  if (phoneQuiz.index + 1 < phoneRounds.length) {
    sceneHistory.push(activePosition);
    activePosition = { key: activePosition.key };
    phoneQuiz.index += 1;
    renderPhoneRound();
    sceneTitle.focus({ preventScroll: true });
    return;
  }

  const { correct } = phoneQuiz;
  goToScene(correct === 0 ? 'phone-game-over' : correct === phoneRounds.length ? 'phone-chat' : 'phone-loop');
}

function showScreen(screen, dlc, dlcSection) {
  if (screen !== 'story' && screen !== 'ending') rewardAudio.pause();
  if (screen !== 'story') {
    clearSceneTimers();
    clearTimeout(morningProfileTimer);
    morningProfileTimer = undefined;
    profileQueue.length = 0;
    activeProfile = undefined;
    if (characterProfile.open) characterProfile.close();
    stopRouteAnimation();
    if (!intertitle.hidden) intertitleAudio.pause();
    if (!sceneAudio.paused) sceneAudio.pause();
  }
  catalog.hidden = screen !== 'catalog';
  novel.hidden = screen === 'catalog';
  novelTabs.hidden = !hasGameAccess() || (screen !== 'menu' && screen !== 'details');
  gameAccessForm.hidden = hasGameAccess();
  playButton.hidden = !hasGameAccess();
  const playingDlc = activeCharacterStory?.dlc;
  gameLabel.textContent = playingDlc ?? dlc?.title ?? 'День Серёжи';
  gameMapLink.href = playingDlc ? dlcMenuHash(activeCharacterStory.id, 'story-map') : '#story-map';
  gameMapLink.hidden = screen !== 'story';
  menu.hidden = screen !== 'menu';
  story.hidden = screen !== 'story';
  ending.hidden = screen !== 'ending';
  novel.classList.toggle('is-playing', screen === 'story');
  novel.classList.toggle('is-ending', screen === 'ending');
  if (activeCharacterStory && (screen === 'story' || screen === 'ending')) {
    backLink.href = activeCharacterStory.dlc ? '#dlc' : characterStoryHash(activeCharacterStory.id);
    backLink.textContent = activeCharacterStory.dlc ? 'К дополнениям' : 'К карте персонажа';
  } else if (dlc) {
    backLink.href = dlcSection ? dlcMenuHash(dlc.character) : '#dlc';
    backLink.textContent = dlcSection ? 'В меню DLC' : 'К дополнениям';
  } else {
    backLink.href = screen === 'menu' ? '#' : '#seryozha';
    backLink.textContent = screen === 'menu' ? 'К играм' : 'В меню игры';
  }
}

const preloadedArt = new Set();
let activeScene;
let activePosition;
const sceneHistory = [];

function updateSceneBack() {
  for (const button of sceneBackButtons) button.disabled = !sceneHistory.length;
}

function startStory(key, { characterStory, ...options } = {}) {
  sceneHistory.length = 0;
  previewedCharacters.clear();
  activeCharacterStory = characterStory;
  phoneQuiz = undefined;
  if (scenes[key].onlyEndCard) showEndCard(scenes[key]);
  else renderScene(key, options);
}

function goToScene(key, options) {
  sceneHistory.push(activePosition);
  if (scenes[key].onlyEndCard) showEndCard(scenes[key]);
  else renderScene(key, { lunch: activePosition?.lunch, ...options });
}

function goBackScene() {
  const previous = sceneHistory.pop();
  if (previous) renderScene(previous.key, previous);
}

function artPath(art) {
  if (art.startsWith('dlc/')) return `assets/${art}.webp`;
  let folder = 'route/';
  if (['wake', 'coffee', 'tea'].includes(art)) folder = '';
  if (art.startsWith('phone-')) folder = 'endings/';
  if (art.startsWith('shift-')) folder = 'shift/';
  if (art.startsWith('diana-')) folder = 'diana/';
  return `assets/${folder}${art}.webp`;
}

function readCharacters() {
  try {
    for (const id of Object.keys(characters)) {
      if (localStorage.getItem(characterStoragePrefix + id) === '1') discoveredCharacters.add(id);
    }
    dianaAlias = localStorage.getItem(dianaAliasStorageKey) ?? dianaAlias;
  } catch {
    // Keep discoveries for the current session if storage is unavailable.
  }
}

function dianaContactName() {
  return discoveredCharacters.has('diana') ? characters.diana.name : 'Неизвестная';
}

function rememberDianaAlias(context) {
  if (activeCharacterStory || developerMode) return;
  if (discoveredCharacters.has('diana') || dianaAlias === 'chat' || dianaAlias === context) return;
  dianaAlias = context;
  try {
    localStorage.setItem(dianaAliasStorageKey, context);
  } catch {
    // The current session still remembers the alias.
  }
}

function lockedCharacterCard(popup = false) {
  const card = document.createElement(popup ? 'div' : 'article');
  card.className = 'character-card character-locked';
  card.setAttribute(popup ? 'aria-hidden' : 'aria-label', popup ? 'true' : 'Персонаж ещё не открыт');
  const portrait = document.createElement('div');
  portrait.className = 'character-silhouette';
  const info = document.createElement('div');
  const title = document.createElement(popup ? 'h2' : 'h3');
  title.textContent = '?????';
  const bio = document.createElement('p');
  bio.textContent = '???????? ??????????? ???????? ???????????? ?????? ??????????';
  info.append(title, bio);
  card.append(portrait, info);
  return card;
}

function characterCard(id, { popup = false, reveal = false } = {}) {
  const { name, art, description, keyword, quote, quoteBy, afterQuote } = characters[id];
  const card = document.createElement(popup ? 'div' : 'article');
  card.className = 'character-card';
  const portrait = document.createElement('img');
  portrait.src = artPath(art);
  portrait.alt = '';
  portrait.width = 320;
  portrait.height = 320;
  const info = document.createElement('div');
  const title = document.createElement(popup ? 'h2' : 'h3');
  if (popup) title.id = 'profile-name';
  title.textContent = name;
  info.append(title);
  if (description) {
    const bio = document.createElement('p');
    bio.textContent = description;
    info.append(bio);
  }
  if (quote) {
    const thought = document.createElement('figure');
    thought.className = 'character-thought';
    const quotation = document.createElement('blockquote');
    quotation.textContent = quote;
    const attribution = document.createElement('figcaption');
    attribution.textContent = quoteBy;
    thought.append(quotation, attribution);
    const outsideOpinion = document.createElement('p');
    outsideOpinion.textContent = afterQuote;
    info.append(thought, outsideOpinion);
  }
  if (id === 'seryozha') {
    const favorite = document.createElement('p');
    favorite.className = 'character-favorite';
    favorite.textContent = 'Фаворит среди девушек на данный момент — ';
    const encountered = popup ? encounteredCharacters() : discoveredCharacters;
    if (encountered.has('yana')) {
      const correction = document.createElement('span');
      correction.className = 'favorite-correction';
      correction.classList.toggle('is-writing', reveal);
      const former = document.createElement('s');
      former.textContent = characters.diana.name;
      const arrow = document.createElement('span');
      arrow.textContent = ' → ';
      arrow.setAttribute('aria-hidden', 'true');
      const current = document.createElement('strong');
      current.textContent = characters.yana.name;
      correction.append(former, arrow, current);
      favorite.append(correction, '.');
    } else if (reveal) {
      const revealName = document.createElement('span');
      revealName.className = 'favorite-reveal';
      const questions = document.createElement('span');
      questions.textContent = '?????';
      questions.setAttribute('aria-hidden', 'true');
      const answer = document.createElement('span');
      answer.textContent = characters.diana.name;
      revealName.append(questions, answer);
      favorite.append(revealName, '.');
    } else {
      favorite.append(encountered.has('diana') ? characters.diana.name : '?????', '.');
    }
    info.append(favorite);
  }
  if (popup && id === 'diana' && dianaAlias) {
    const alias = document.createElement('p');
    alias.className = 'character-alias';
    alias.textContent = dianaAlias === 'chat' ? 'В переписке — «Неизвестная»' : 'В вариантах ответа — «Неизвестная»';
    info.append(alias);
  }
  if (keyword) {
    const trait = document.createElement('p');
    trait.className = 'character-keyword';
    const word = document.createElement('strong');
    word.textContent = keyword;
    trait.append('В одном слове ', word);
    info.append(trait);
  }
  if (!popup && canOpenCharacterStory(id)) {
    const actions = document.createElement('div');
    actions.className = 'character-story-actions';
    const dlc = downloadableStories.find(({ character, roadmap }) => character === id && roadmap?.[0]?.scene);
    if (dlc) {
      const play = document.createElement('a');
      play.className = 'pixel-button';
      play.href = dlcMenuHash(id);
      play.textContent = `Пройти сюжет ${characterStories[id].name}`;
      actions.append(play);
    } else if (id === 'seryozha' || characterStories[id].episodes.length) {
      const play = document.createElement('button');
      play.type = 'button';
      play.className = 'pixel-button';
      play.textContent = `Пройти сюжет ${characterStories[id].name}`;
      play.addEventListener('click', () => playCharacterStory(id));
      actions.append(play);
    }
    const map = document.createElement('a');
    map.className = 'nav-link';
    map.href = characterStoryHash(id);
    map.textContent = 'Карта сюжета';
    actions.append(map);
    info.append(actions);
  }
  card.append(portrait, info);
  return card;
}

function renderCharacters() {
  const showAll = developerMode && developerUnlockCharacters.checked;
  characterList.replaceChildren(...Object.keys(characters).map((id) => {
    const visible = showAll || id === 'seryozha' || characters[id].visibleFromStart || discoveredCharacters.has(id);
    return visible ? characterCard(id) : lockedCharacterCard();
  }));
}

function resetCharacters() {
  if (!window.confirm('Сбросить знакомства? Карточки снова появятся при прохождении.')) return;

  const status = document.querySelector('#character-reset-status');
  try {
    for (const id of Object.keys(characters)) localStorage.removeItem(characterStoragePrefix + id);
    localStorage.removeItem(dianaAliasStorageKey);
    status.textContent = 'Знакомства сброшены.';
  } catch {
    status.textContent = 'Знакомства сброшены в этой вкладке. Хранилище браузера недоступно.';
  }
  discoveredCharacters.clear();
  dianaAlias = undefined;
  renderCharacters();
}

function encounteredCharacters() {
  return developerMode ? previewedCharacters : discoveredCharacters;
}

function showNextCharacterProfile() {
  if (story.hidden || characterProfile.open) return;
  const encountered = encounteredCharacters();
  let entry;
  do {
    entry = profileQueue.shift();
  } while (entry && !entry.reveal && !entry.review && encountered.has(entry.id));
  if (!entry) return;
  activeProfile = entry.review ? undefined : entry.id;
  const card = characterCard(entry.id, { popup: true, reveal: entry.reveal });
  const showMask = !entry.reveal && !entry.review;
  characterProfileBody.classList.toggle('character-unlock', showMask);
  characterProfileBody.replaceChildren(...(showMask ? [lockedCharacterCard(true), card] : [card]));
  characterProfile.showModal();
  if (entry.review) return;
  encountered.add(entry.id);
  if (developerMode) return;
  try {
    localStorage.setItem(characterStoragePrefix + entry.id, '1');
  } catch {
    // In-memory progress still prevents duplicate pop-ups.
  }
}

function showCharacterEncounters(key, meet = [], reviewKnown = false) {
  if (key === 'morning' && !encounteredCharacters().has('seryozha') && morningProfileTimer === undefined) {
    morningProfileTimer = setTimeout(() => {
      morningProfileTimer = undefined;
      profileQueue.push({ id: 'seryozha' });
      showNextCharacterProfile();
    }, 2000);
  }
  const encountered = encounteredCharacters();
  profileQueue.push(...meet.map((id) => ({ id, review: reviewKnown && encountered.has(id) })));
  showNextCharacterProfile();
}

function preloadScene(key) {
  const { art, poster, endCardArt } = scenes[key];
  const image = endCardArt ?? art;
  preloadArt(poster ?? (image && artPath(image)));
}

function preloadArt(path) {
  if (!path || preloadedArt.has(path)) return;
  preloadedArt.add(path);
  new Image().src = path;
}

function renderIntertitle(scene) {
  const visible = Boolean(scene.intertitle);
  if (!intertitle.hidden) intertitleAudio.pause();
  intertitle.hidden = !visible;
  dialogue.hidden = visible;
  if (!visible) return;

  intertitleArt.src = scene.poster;
  intertitleArt.alt = scene.title;
  intertitleArt.lang = scene.intertitleLang ?? 'en';
  intertitleStatus.textContent = '';
  intertitleSound.hidden = !scene.audio;
  intertitleSound.setAttribute('aria-pressed', 'false');
  if (!scene.audio) return;
  if (intertitleAudio.getAttribute('src') !== scene.audio) intertitleAudio.src = scene.audio;
  intertitleAudio.currentTime = 0;
}

function renderWorkCall({ callStage: stage, callGroup: group }) {
  workCall.hidden = stage === undefined;
  if (workCall.hidden) return;

  for (const message of workCallMessages) {
    const cue = scenes[message.dataset.callMessage];
    message.hidden = cue.callGroup !== group || cue.callStage > stage;
    message.querySelector('span').textContent = cue.line;
  }
  const bothLive = group === 'blender' && stage >= 2;
  workCallStreamLabel.textContent = bothLive ? 'Две демонстрации Blender' : 'Демонстрация экрана';
  for (const badge of workCallLiveBadges) badge.hidden = !bothLive;
  workCallProgrammer.classList.toggle('work-person-speaking', stage === 1 || stage === 3);
  workCallDesigner.classList.toggle('work-person-speaking', stage === 2);
}

function renderSceneTitle(scene) {
  const showPrice = scene.prop === 'ozon-price';
  sceneTitle.classList.toggle('ozon-price', showPrice);
  if (!showPrice) {
    sceneTitle.textContent = !discoveredCharacters.has('diana') && scene.unknownTitle ? scene.unknownTitle : scene.title;
    return;
  }

  const amount = scene.title.replace(/ ₽$/, '');
  const digit = document.createElement('span');
  digit.className = 'ozon-price-digit';
  digit.textContent = amount.at(-1);
  sceneTitle.replaceChildren(amount.slice(0, -1), digit, scene.title.slice(amount.length));
}

function clearSceneTimers() {
  for (const timer of sceneTimers) clearTimeout(timer);
  sceneTimers.length = 0;
  scenePicture.classList.remove('is-ripple-collapse');
  cancelAnimationFrame(voiceSequenceFrame);
  voiceSequence = undefined;
  continueButton.disabled = false;
}

function runSceneSequence(times, step) {
  continueButton.disabled = true;
  for (const [index, delay] of times.entries()) sceneTimers.push(setTimeout(() => step(index), delay));
  sceneTimers.push(setTimeout(() => { continueButton.disabled = false; }, times.at(-1) + 850));
}

function syncVoiceSequence(playback) {
  const sequence = voiceSequence;
  const lastCue = sequence.times.at(-1);
  let index = 0;
  let fallbackStart;
  playback.catch(() => { fallbackStart = performance.now(); });
  const update = (now) => {
    if (voiceSequence !== sequence) return;
    const elapsed = fallbackStart === undefined ? sceneAudio.currentTime * 1000 : now - fallbackStart;
    while (index < sequence.times.length && elapsed >= sequence.times[index]) sequence.step(index++);
    if (elapsed >= lastCue + 850 || (sceneAudio.ended && index === sequence.times.length)) {
      continueButton.disabled = false;
    } else {
      voiceSequenceFrame = requestAnimationFrame(update);
    }
  };
  voiceSequenceFrame = requestAnimationFrame(update);
}

function renderNightVoice(mode, roster = nightRoster) {
  const usesCustomRoster = roster !== nightRoster;
  nightVoice.hidden = !mode;
  nightVoiceGrid.classList.toggle('is-church-call', usesCustomRoster);
  if (!mode) return;
  const focus = roster.findIndex(({ id }) => id === mode);
  const tiles = roster.map(({ nick, avatar }, index) => {
    const tile = document.createElement('li');
    tile.className = 'night-voice-tile';
    tile.classList.toggle('is-focused', focus === index);
    tile.classList.toggle('is-dimmed', focus !== -1 && focus !== index);
    tile.hidden = mode === 'joining' ? index > 1 : mode === 'alone' && index > 0;
    const portrait = document.createElement('img');
    portrait.src = avatar;
    portrait.alt = '';
    const name = document.createElement('strong');
    name.textContent = nick;
    tile.append(portrait, name);
    return tile;
  });
  nightVoiceGrid.replaceChildren(...tiles);
  nightReaction.hidden = usesCustomRoster || (focus === -1 && mode !== 'joining');
  if (!nightReaction.hidden) nightReaction.src = artPath(`night-reaction-${Math.max(focus, 0) + 1}`);
  const updateCount = () => { nightVoiceCount.textContent = `В канале ${tiles.filter((tile) => !tile.hidden).length}`; };
  updateCount();
  const joining = mode === 'joining';
  if (joining || mode === 'leaving') {
    continueButton.disabled = true;
    voiceSequence = {
      times: joining ? nightJoinTimes : nightLeaveTimes,
      step: (index) => {
        tiles[joining ? index + 2 : tiles.length - 1 - index].hidden = !joining;
        updateCount();
      },
    };
  }
}

function renderNightProps(scene) {
  const { clockCard, timeBadge, phoneNote, dioramaView, prop } = scene;
  nightClockCard.hidden = !clockCard;
  nightClockCard.textContent = clockCard ?? '';
  sceneArt.hidden = Boolean(clockCard);
  nightTimeBadge.hidden = !timeBadge;
  nightTimeBadge.textContent = timeBadge ?? '';
  churchFallLettering.hidden = prop !== 'church-fall';
  churchTelegramExamples.hidden = phoneNote !== 'church-telegram';
  if (!churchTelegramExamples.hidden && !churchTelegramExamples.hasAttribute('src')) {
    churchTelegramExamples.src = artPath('church-examples');
  }
  nightPhoneNote.hidden = !phoneNote;
  if (phoneNote) {
    nightPhoneNote.dataset.note = phoneNote;
    [nightPhoneSource.textContent, nightPhoneText.textContent] = nightPhoneMessages[phoneNote];
    const missed = phoneNote === 'sleep-missed';
    nightPhoneSecond.hidden = !missed && phoneNote !== 'two-chats';
    nightPhoneSecond.firstElementChild.textContent = missed ? 'Discord · Общая группа' : 'Telegram · Серёжа';
    nightPhoneSecond.lastElementChild.textContent = missed ? 'Много новых сообщений' : 'Открыт чат';
  }
  dioramaCheck.hidden = !dioramaView;
  if (dioramaView) {
    dioramaCheck.dataset.view = dioramaView;
    const cubesVisible = dioramaView === 'cubes' || dioramaView === 'platform';
    dioramaTitle.textContent = dioramaView === 'cubes' ? 'Две демонстрации Blender' : 'Экран Димы';
    dioramaNote.textContent = dioramaView === 'capture' ? 'За 10 минут до проверки' : 'Blender';
    dioramaPhoto.hidden = cubesVisible;
    dioramaCubes.hidden = !cubesVisible;
    dioramaFirstCube.hidden = dioramaView === 'platform';
    dioramaSelection.hidden = dioramaView !== 'selected' && dioramaView !== 'capture';
  }
  nightVideoScroll.hidden = prop !== 'shorts-timelapse';
  nightCharacterSwitch.hidden = prop !== 'character-switch';
  scenePicture.dataset.nightEffect = prop ?? '';
  sleepBubble.hidden = prop !== 'deep-sleep';
  nightDiscord.hidden = prop !== 'sleep-discord';
  if (!nightDiscord.hidden && !nightDiscordShots.childElementCount) {
    nightDiscordPlayers.textContent = nightRoster
      .filter(({ id }) => id !== 'seryozha')
      .map(({ id }) => characters[id].name)
      .join(' · ');
    for (const [name, art] of nightGames) {
      const shot = document.createElement('li');
      const image = document.createElement('img');
      image.src = artPath(art);
      image.alt = '';
      image.width = 832;
      image.height = 468;
      const caption = document.createElement('span');
      caption.textContent = name;
      shot.append(image, caption);
      nightDiscordShots.append(shot);
    }
  }
  if (prop === 'lecture-timelapse') {
    for (const [, art] of lectureFrames) preloadArt(artPath(art));
    runSceneSequence([1050, 2100], (index) => {
      const [time, art, alt] = lectureFrames[index];
      nightTimeBadge.textContent = time;
      sceneArt.src = artPath(art);
      sceneArt.alt = alt;
    });
  }
  if (prop === 'museum-timelapse') {
    const frames = [
      ['night-museum-point', 'Подруга Дианы показывает остальным детали большого макета.'],
      ['night-museum-recover', 'Дима и Кирилл приходят в себя и с интересом разглядывают экспонат.'],
    ];
    for (const [art] of frames) preloadArt(artPath(art));
    runSceneSequence([1050, 2100], (index) => {
      const [art, alt] = frames[index];
      sceneArt.src = artPath(art);
      sceneArt.alt = alt;
    });
  }
  nightGameName.hidden = prop !== 'night-games' && !scene.montageCaption;
  if (scene.montage) {
    nightGameName.textContent = scene.montageCaption ?? '';
    for (const { art } of scene.montage) preloadArt(artPath(art));
    runSceneSequence(scene.montage.map(({ delay }) => delay), (index) => {
      const { art, alt, caption } = scene.montage[index];
      sceneArt.src = artPath(art);
      sceneArt.alt = alt ?? '';
      if (caption) nightGameName.textContent = caption;
    });
  }
  if (prop === 'night-games') {
    nightGameName.textContent = nightGames[0][0];
    for (const [, art] of nightGames.slice(1)) preloadArt(artPath(art));
    runSceneSequence(nightGames.slice(1).map((_, index) => 720 * (index + 1)), (index) => {
      const [game, art] = nightGames[index + 1];
      nightGameName.textContent = game;
      sceneArt.src = artPath(art);
      sceneArt.alt = `Игровой вечер — ${game}`;
    });
  }
}

const holdemRankNames = { T: '10', J: 'валет', Q: 'дама', K: 'король', A: 'туз' };
const holdemSuitNames = { c: 'треф', d: 'бубен', h: 'червей', s: 'пик' };

function renderHoldem(scene) {
  holdemBet.hidden = !scene.holdemBet;
  holdemBet.textContent = scene.holdemBet ? `Фишки ${scene.holdemBet}` : '';
  const hand = scene.holdem;
  holdemPanel.hidden = !hand;
  holdemPanel.dataset.layout = hand?.layout ?? '';
  holdemPanel.replaceChildren();
  if (!hand) return;

  if (hand.title) {
    const title = document.createElement('h2');
    title.textContent = hand.title;
    holdemPanel.append(title);
  }
  const table = document.createElement('div');
  table.className = 'holdem-table';
  for (const [label, cards] of [['На столе', hand.board], ['На руках', hand.hole]]) {
    if (!cards?.length) continue;
    const group = document.createElement('div');
    group.className = 'holdem-group';
    const groupLabel = document.createElement('span');
    groupLabel.textContent = label;
    const row = document.createElement('div');
    row.className = 'holdem-cards';
    for (const code of cards) {
      const [rank, suit] = code;
      const highlighted = hand.highlight?.includes(code);
      const card = document.createElement('img');
      card.className = 'holdem-card';
      card.classList.toggle('holdem-card-highlighted', Boolean(highlighted));
      card.classList.toggle('holdem-card-muted', Boolean(hand.highlight && !highlighted));
      card.src = `assets/cards/${code}.svg`;
      card.alt = `${holdemRankNames[rank] ?? rank} ${holdemSuitNames[suit]}${highlighted ? ', в комбинации' : ''}`;
      card.width = 159;
      card.height = 235;
      row.append(card);
    }
    group.append(groupLabel, row);
    table.append(group);
  }
  holdemPanel.append(table);
  if (hand.layout === 'manga') {
    const caption = document.createElement('p');
    caption.className = 'holdem-manga-caption';
    caption.textContent = scene.line;
    holdemPanel.append(caption);
  }
}

const lunchRegulars = ['dima', 'seryozha', 'nikita'];
const pokerSeatPositions = [[43, 84], [32, 54], [50, 27], [64, 35], [69, 54], [59, 84], [37, 35]];
const minimumPokerPlayers = 6;

function lunchInvitees(progress) {
  return progress.asked.filter((id) => cafeteriaGuests[id].joins);
}

function lunchPartyComplete(party, progress) {
  return party.seats.every((id) => progress.asked.includes(id));
}

function lunchExitScene(progress) {
  const count = lunchInvitees(progress).length;
  if (lunchRegulars.length + count >= minimumPokerPlayers) return 'history-lunch-poker';
  return count ? 'history-cafeteria-dismiss' : 'history-golf-plan';
}

function restoreLunchProgress(saved) {
  const asked = Array.isArray(saved?.asked)
    ? [...new Set(saved.asked.filter((id) => Object.hasOwn(cafeteriaGuests, id)))] : [];
  return {
    asked,
    spoke: saved?.spoke === true,
    door: asked.includes('apparition'),
    aside: cafeteriaParties.some(({ id }) => id === saved?.aside) ? saved.aside : null,
  };
}

function leaveLunchTable(party, progress) {
  const atHall = { ...progress, spoke: false, aside: null };
  if (progress.spoke && !lunchPartyComplete(party, progress)) {
    const hasAside = party.seats.some((id) => !progress.asked.includes(id) && cafeteriaGuests[id].aside);
    if (hasAside) {
      goToScene('history-cafeteria-aside', { lunch: { ...atHall, aside: party.id } });
      return;
    }
  }
  const finished = cafeteriaParties.every((table) => lunchPartyComplete(table, progress));
  goToScene(finished && !atHall.door ? lunchExitScene(atHall) : 'history-cafeteria', { lunch: atHall });
}

function lunchGuestName(id) {
  return cafeteriaGuests[id].name ?? characters[id]?.name ?? '???';
}

function makeLunchButton(className, label, action) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.setAttribute('aria-label', label);
  button.addEventListener('click', action);
  return button;
}

function lunchPortrait(id, known) {
  const portrait = document.createElement('span');
  portrait.className = 'lunch-portrait';
  portrait.classList.toggle('is-unknown', !known);
  portrait.classList.toggle('is-cake', id === 'cake');
  if (characters[id]) {
    const image = document.createElement('img');
    image.src = artPath(characters[id].art);
    image.alt = '';
    portrait.append(image);
  }
  return portrait;
}

function positionLunchSeat(element, [x, y]) {
  element.style.setProperty('--seat-x', x + '%');
  element.style.setProperty('--seat-y', y + '%');
}

function renderLunchPoker(scene, progress) {
  lunchPokerSeats.hidden = !scene.lunchPoker;
  lunchPokerSeats.classList.toggle('is-winner-line', scene.lunchPoker === 'win');
  lunchPokerSeats.replaceChildren();
  if (!scene.lunchPoker) return;

  const players = [...lunchRegulars, ...lunchInvitees(progress)];
  for (const [index, id] of players.entries()) {
    const seat = document.createElement('li');
    seat.className = 'lunch-poker-player';
    positionLunchSeat(seat, pokerSeatPositions[index]);
    seat.classList.toggle('is-lunch-winner', scene.lunchPoker === 'win' && id === 'nikita');
    const name = document.createElement('span');
    name.textContent = characters[id].name;
    seat.append(lunchPortrait(id, true), name);
    lunchPokerSeats.append(seat);
  }
}

function renderLunch(scene, progress) {
  renderLunchPoker(scene, progress);
  lunchScore.hidden = !scene.lunchScore;
  lunchGlasses.hidden = !scene.lunchGlasses;
  lunchHotspots.hidden = !scene.cafeteria;
  lunchHotspots.replaceChildren();
  scenePicture.classList.toggle('is-lunch-hall', scene.cafeteria === 'hall');
  scenePicture.classList.toggle('is-lunch-table', Boolean(scene.cafeteria && scene.cafeteria !== 'hall'));
  scenePicture.classList.toggle('is-lunch-blackout', Boolean(scene.blackout));
  scenePicture.classList.toggle('is-lunch-reveal', Boolean(scene.lunchReveal));
  sceneArt.hidden = Boolean(scene.blackout);
  if (scene.lunchScore) {
    const names = [...lunchRegulars, ...lunchInvitees(progress)].map((id) => characters[id].name);
    lunchCount.textContent = names.length + '/' + minimumPokerPlayers;
    lunchNames.replaceChildren(...names.map((name) => {
      const item = document.createElement('li');
      item.textContent = name;
      return item;
    }));
  }
  if (!scene.cafeteria) return;

  const known = encounteredCharacters();
  const visible = (id) => !(['cake', 'liza', 'apparition'].includes(id) && progress.asked.includes(id));
  if (scene.cafeteria === 'hall') {
    for (const party of cafeteriaParties) {
      const remaining = party.seats.filter(visible);
      const allUnknown = !remaining.some((id) => known.has(id));
      const names = allUnknown ? '???' : remaining.map((id) => known.has(id) ? lunchGuestName(id) : '???').join(', ');
      const label = party.title ? party.title + ' · ' + names : names;
      const complete = lunchPartyComplete(party, progress);
      const table = makeLunchButton('lunch-table', complete ? label + ' · Очарованы Серёжей' : label, () => {
        goToScene('history-cafeteria-' + party.id, { lunch: { ...progress, spoke: false }, lunchArrival: true });
      });
      table.disabled = complete;
      table.classList.toggle('is-unknown', allUnknown);
      table.style.setProperty('--table-x', party.position[0] + '%');
      table.style.setProperty('--table-y', party.position[1] + '%');
      const caption = document.createElement('span');
      caption.className = 'lunch-table-caption';
      caption.textContent = complete ? 'Очарованы Серёжей' : label;
      const group = document.createElement('span');
      group.className = 'lunch-table-group';
      group.setAttribute('aria-hidden', 'true');
      group.append(...remaining.map((id) => lunchPortrait(id, known.has(id))));
      if (allUnknown && !complete) {
        const mystery = document.createElement('span');
        mystery.className = 'lunch-question';
        mystery.textContent = '?';
        group.append(mystery);
      }
      table.append(caption, group);
      lunchHotspots.append(table);
    }
    if (progress.door) {
      const door = makeLunchButton('lunch-door choice', 'Приоткрытая дверь', () => goToScene('history-cafeteria-secret'));
      door.textContent = 'Приоткрытая дверь';
      lunchHotspots.append(door);
    }
    return;
  }

  const party = cafeteriaParties.find(({ id }) => id === scene.cafeteria);
  if (party.afterArt) preloadArt(artPath(party.afterArt));
  const useEmptyFrame = party.afterArt && !visible('liza');
  const faces = useEmptyFrame ? party.afterFaces : party.faces;
  if (useEmptyFrame) sceneArt.src = artPath(party.afterArt);
  for (const [index, id] of party.seats.entries()) {
    if (!visible(id)) {
      const empty = document.createElement('span');
      empty.className = 'lunch-empty-seat';
      empty.textContent = 'Пустой стул';
      positionLunchSeat(empty, faces[index]);
      lunchHotspots.append(empty);
      continue;
    }
    const name = lunchGuestName(id);
    const guest = cafeteriaGuests[id];
    const button = makeLunchButton('lunch-seat', 'Позвать в покер · ' + name, () => {
      const lunch = { ...progress, asked: [...progress.asked, id], spoke: true };
      goToScene(guest.reply ?? 'history-cafeteria-' + party.id + '-' + id, { lunch });
    });
    button.disabled = progress.asked.includes(id);
    button.classList.toggle('is-mystery', !characters[id]);
    positionLunchSeat(button, faces[index]);
    const caption = document.createElement('span');
    caption.className = 'lunch-seat-caption';
    const label = document.createElement('span');
    label.textContent = name;
    const hint = document.createElement('small');
    hint.className = 'lunch-seat-hint';
    hint.textContent = button.disabled ? 'Уже спросили' : 'Позвать в покер';
    caption.append(label, hint);
    button.append(caption);
    lunchHotspots.append(button);
  }
}

function lunchSceneLine(scene, progress) {
  if (scene.lunchDismissal) return lunchInvitees(progress).map((id) => characters[id].name).join(', ') + ' — в другой раз сыграем, извинитесь.';
  if (scene.lunchPoker === 'deal') {
    const players = [...lunchRegulars, ...lunchInvitees(progress)];
    return scene.line + ' За столом ' + players.map((id) => characters[id].name).join(', ') + '.';
  }
  if (scene.lunchAside) {
    const party = cafeteriaParties.find(({ id }) => id === progress.aside);
    const remarks = party?.seats.filter((id) => !progress.asked.includes(id) && cafeteriaGuests[id].aside)
      .map((id) => lunchGuestName(id) + ': «' + cafeteriaGuests[id].aside + '»') ?? [];
    const intro = party?.id === 'teachers'
      ? 'Учителя шепчутся за спиной. Я слышу краем уха, но иду дальше.'
      : 'Мы отходим от стола, и я слышу за спиной:';
    return remarks.length ? intro + '\n' + remarks.join('\n') : 'Мы отходим от стола.';
  }
  return scene.line ?? '';
}

function renderScene(key, { phone, lunch, lunchArrival = false, remember = true } = {}) {
  rewardAudio.pause();
  clearSceneTimers();
  const scene = activeCharacterStory?.nextByScene
    ? { ...scenes[key], next: activeCharacterStory.nextByScene.get(key) }
    : scenes[key];
  activeScene = scene;
  const lunchProgress = restoreLunchProgress(lunch);
  activePosition = { key, lunch: lunchProgress };
  updateSceneBack();
  if (!activeCharacterStory || activeCharacterStory.dlc) rememberStoryStart(key);
  if (!activeCharacterStory && remember) {
    if (scene.cafeteria || scene.lunchScore) rememberDecision(key, undefined, lunchProgress);
    else if (scene.options) rememberDecision(key);
  }
  renderIntertitle(scene);
  renderWorkCall(scene);
  renderNightProps(scene);
  renderNightVoice(scene.nightVoice, scene.voiceRoster);
  const blenderStage = scene.blenderStage;
  blenderLaunch.hidden = blenderStage !== 'launch';
  blenderWorkspace.hidden = blenderStage !== 'workspace';
  blenderChat.hidden = blenderStage !== 'chat' && blenderStage !== 'draft';
  blenderDraft.hidden = blenderStage !== 'draft';
  blenderDimaScreen.hidden = blenderStage !== 'shorts' && blenderStage !== 'cube';
  blenderDimaScreen.dataset.focus = blenderStage ?? '';
  blenderFiles.hidden = blenderStage !== 'files' && blenderStage !== 'recent-files';
  blenderFiles.classList.toggle('shows-recent-files', blenderStage === 'recent-files');
  blenderProjectLabels.hidden = scene.prop !== 'blender-project';
  blenderModelProgress.hidden = scene.modelProgress === undefined;
  if (!blenderModelProgress.hidden) {
    const progress = blenderModelProgress.querySelector('progress');
    progress.value = scene.modelProgress;
    blenderModelProgress.querySelector('span').textContent = `${scene.modelProgress}%`;
  }
  scenePicture.classList.toggle('has-blender-screen', Boolean(blenderStage || scene.dioramaView));
  scenePicture.classList.toggle('is-blender-twitch', scene.prop === 'blender-eye-twitch');
  historyClassroomPlates.hidden = scene.prop !== 'history-doors';
  const seesInformaticsPlaque = scene.prop === 'history-informatics-plaque';
  historyInformaticsPlate.hidden = !seesInformaticsPlaque && scene.prop !== 'history-informatics-door';
  historyInformaticsPlate.classList.toggle('is-closeup', seesInformaticsPlaque);
  historyLockscreen.hidden = scene.prop !== 'history-date';
  historyDoorSlam.hidden = scene.prop !== 'card-door-slam';
  scenePicture.hidden = Boolean(scene.intertitle || scene.holdem?.layout) || !workCall.hidden || !nightVoice.hidden;
  renderHoldem(scene);
  thoughtBubble.hidden = !scene.thought;
  thoughtBubble.classList.toggle('thought-angry', Boolean(scene.thought?.angry));
  thoughtMoney.hidden = !scene.thought?.money;
  thoughtText.textContent = scene.thought?.text ?? '';
  fingerMovement.hidden = scene.prop !== 'finger';
  if (scene.quiz) {
    phoneQuiz = { index: 0, correct: 0, ...phone, answered: false };
    for (const next of ['phone-game-over', 'phone-chat', 'phone-loop']) preloadScene(next);
  } else if (phone) {
    phoneQuiz = { ...phone };
  }
  const showScore = scene.quiz || scene.phoneResult || scene.prop === 'chat';
  phoneScoreboard.hidden = !showScore;
  phoneRoundLabel.hidden = !scene.quiz;
  if (showScore) {
    phoneQuiz ??= {
      index: phoneRounds.length - 1,
      correct: scene.prop === 'chat' ? phoneRounds.length : Number(scene.ending === 'time-loop'),
    };
    activePosition.phone = { index: phoneQuiz.index, correct: phoneQuiz.correct };
    updatePhoneScore();
  }
  answerFeedback.hidden = true;
  gameOverTitle.hidden = scene.ending !== 'game-over';
  endingAward.hidden = !scene.ending;
  dianaChat.hidden = scene.prop !== 'chat';
  ozonChat.hidden = scene.prop !== 'ozon-montage';
  if (!ozonChat.hidden) {
    rememberDianaAlias('chat');
    ozonChatName.textContent = dianaContactName();
  }
  scenePicture.classList.toggle('has-ending-award', Boolean(scene.ending));
  scenePicture.classList.toggle('is-achievement', scene.prop === 'achievement');
  scenePicture.classList.toggle('has-chat', scene.prop === 'chat');
  const endingResult = endings.find(({ id }) => id === scene.ending);
  if (endingResult) {
    if (!activeCharacterStory) unlockEnding(endingResult.id);
    endingAward.replaceChildren(rewardCard(endingResult, true, 'h2'));
  }
  const earnedAchievement = renderAchievementAward(
    scene.achievement, scene.holdem?.layout ? holdemPanel : scenePicture,
  );
  if (scene.prop === 'chat') renderDianaChat(scene.dianaReply);
  scenePicture.classList.toggle('is-dull-view', scene.prop === 'dull-view');
  scenePicture.classList.toggle('is-rain-reveal', scene.prop === 'rain-reveal');
  scenePicture.classList.toggle('is-fainting', scene.prop === 'fainting');
  scenePicture.classList.toggle('is-opening-eyes', scene.prop === 'opening-eyes');
  scenePicture.classList.toggle('is-pulling-back', scene.prop === 'pullback');
  doorNameplate.hidden = scene.prop !== 'door-nameplate';
  const onRoute = scene.routeIndex !== undefined;
  scenePicture.classList.toggle('is-route', onRoute);
  routeMap.hidden = !onRoute;
  routeCaption.hidden = !onRoute;
  shoppingLabels.hidden = scene.prop !== 'shopping';
  ozonNametags.hidden = scene.prop !== 'ozon-nametags';
  phoneProjection.hidden = scene.prop !== 'phone';

  if (scene.art) {
    sceneArt.src = artPath(scene.art);
    sceneArt.alt = scene.alt ?? '';
  }
  renderLunch(scene, lunchProgress);
  renderSceneTitle(scene);
  sceneSpeaker.textContent = scene.prop === 'achievement' && developerMode && !developerSaveAchievements.checked
    ? 'Предпросмотр достижения'
    : scene.speaker ?? 'Серёжа';
  sceneLine.textContent = (!discoveredCharacters.has('diana') ? scene.unknownLine : undefined) ?? lunchSceneLine(scene, lunchProgress);
  sceneLine.hidden = !sceneLine.textContent || scene.callStage > 0 || scene.holdem?.layout === 'manga';
  sceneLine.classList.toggle('has-lunch-aside', Boolean(scene.lunchAside));
  sceneSpeaker.hidden = Boolean(scene.silentFrame);
  sceneTitle.hidden = Boolean(scene.silentFrame);
  choices.classList.toggle('choices-overlay', Boolean(scene.choiceOverlay));
  if (scene.choiceOverlay) scenePicture.append(choices);
  else if (choices.parentElement !== dialogue) dialogue.insertBefore(choices, answerFeedback);
  choices.replaceChildren();
  for (const [label, next] of scene.options ?? []) {
    addChoice(label, () => goToScene(next));
    preloadScene(next);
  }
  if (scene.next) preloadScene(scene.next);
  choices.hidden = !scene.options && !scene.quiz;
  continueButton.hidden = Boolean(scene.options) || blenderStage === 'launch' || blenderStage === 'workspace';
  continueButton.textContent = scene.cafeteria === 'hall' ? 'Выйти из столовой' : scene.continueLabel ?? 'Дальше';
  if (scene.waitForSound) continueButton.disabled = true;
  if (scene.quiz) renderPhoneRound();
  showScreen('story');
  if (scene.autoAdvance && scene.next) {
    continueButton.disabled = true;
    sceneTimers.push(setTimeout(() => renderScene(scene.next), scene.autoAdvance));
  }
  if (!sceneAudio.paused) sceneAudio.pause();
  sceneAudio.loop = Boolean(scene.loopSound);
  stormLight.hidden = !scene.lightning;
  stormLight.classList.toggle('is-vanish', scene.lightning === 'vanish');
  const sound = scene.sound ?? (scene.lightning ? 'assets/route/kirill-thunder.mp3' : null);
  if (sound) {
    if (sceneAudio.getAttribute('src') !== sound) sceneAudio.src = sound;
    sceneAudio.currentTime = 0;
    const playback = sceneAudio.play();
    if (voiceSequence) syncVoiceSequence(playback);
    else playback.catch(() => {
      if (activeScene === scene && scene.waitForSound && !story.hidden) continueButton.disabled = false;
    });
  }
  const rewardSound = endingResult?.audio ?? (earnedAchievement ? 'assets/rewards/achievement-fanfare.mp3' : null);
  if (rewardSound) {
    if (rewardAudio.getAttribute('src') !== rewardSound) rewardAudio.src = rewardSound;
    rewardAudio.volume = sound ? 0.4 : 1;
    rewardAudio.currentTime = 0;
    rewardAudio.play().catch(() => {});
  }
  if (onRoute) {
    routeStep.textContent = `${scene.routeIndex + 1} / ${workTrip.length}`;
    routeMap.setAttribute('aria-label', `Путь Серёжи из Пигелево. Сейчас: ${scene.title}.`);
    showRouteStop(scene.routeIndex);
  } else {
    stopRouteAnimation();
  }
  const focusTarget = scene.intertitle ? intertitleNext : scene.silentFrame ? continueButton : sceneTitle;
  focusTarget.focus({ preventScroll: true });
  window.scrollTo(0, 0);
  if (!activeCharacterStory || developerMode) {
    const party = lunchArrival ? cafeteriaParties.find(({ id }) => id === scene.cafeteria) : undefined;
    const tableGuests = party?.seats.filter((id) => characters[id] && (id !== 'liza' || !lunchProgress.asked.includes(id)));
    showCharacterEncounters(key, tableGuests ?? scene.meet, Boolean(party));
  }
}

function syncRoute(moveFocus = false) {
  let hash = window.location.hash;
  if (!developerMode) {
    const publicHash = hash === '#all-scenes' ? '#story-map' : hash.replace(/^(#dlc\/[^/]+)\/all-scenes$/, '$1/story-map');
    if (hash !== publicHash) {
      hash = publicHash;
      window.history.replaceState(null, '', hash);
    }
  }
  if (!hasGameAccess() && /^#(?:achievements|characters|story-map|character-story(?:\/.*)?|dlc(?:\/.*)?)$/.test(hash)) {
    hash = '#seryozha';
    window.history.replaceState(null, '', hash);
  }
  readCharacters();
  if (hash === '#character-story/seryozha') {
    hash = characterStoryHash('seryozha');
    window.history.replaceState(null, '', hash);
  }
  const characterStoryId = hash.startsWith('#character-story/') ? hash.slice('#character-story/'.length) : undefined;
  const inCharacterStory = characterStoryId !== undefined && canOpenCharacterStory(characterStoryId);
  if (characterStoryId !== undefined && !inCharacterStory) {
    hash = '#characters';
    window.history.replaceState(null, '', hash);
  }
  const [, dlcCharacter, dlcSection] = hash.match(/^#dlc\/([^/]+)(?:\/(achievements|story-map|all-scenes))?$/) ?? [];
  const dlcEntry = downloadableStories.find(({ character, roadmap }) =>
    character === dlcCharacter && roadmap?.[0]?.scene);
  const dlc = dlcEntry && hasDlcAccess(dlcCharacter) ? dlcEntry : undefined;
  const dlcToActivate = dlcEntry && !dlc && !dlcSection && canActivateDlc(dlcCharacter) ? dlcEntry : undefined;
  if (hash.startsWith('#dlc/') && !dlc && !dlcToActivate) {
    hash = '#dlc';
    window.history.replaceState(null, '', hash);
  }
  const inGame = hash === '#seryozha';
  const inAchievements = hash === '#achievements';
  const inCharacters = hash === '#characters';
  const inStoryMap = hash === '#story-map';
  const inDlc = hash === '#dlc' || Boolean(dlcToActivate);
  const inAllScenes = developerMode && hash === '#all-scenes';
  const highlightedTab = inAllScenes ? allScenesTab : inStoryMap ? storyMapTab : inAchievements ? achievementsTab : inCharacters || inCharacterStory ? charactersTab : inDlc ? dlcTab : null;
  for (const tab of [achievementsTab, charactersTab, storyMapTab, allScenesTab, dlcTab]) {
    if (tab === highlightedTab) tab.setAttribute('aria-current', 'page');
    else tab.removeAttribute('aria-current');
  }
  achievementsPanel.hidden = !inAchievements;
  charactersPanel.hidden = !inCharacters;
  storyMapPanel.hidden = !inStoryMap;
  dlcPanel.hidden = !inDlc;
  dlcMenuPanel.hidden = !dlc;
  characterStoryPanel.hidden = !inCharacterStory;
  allScenesTab.hidden = !developerMode;
  allScenesPanel.hidden = !inAllScenes;
  if (!developerMode) {
    allScenesPanel.querySelector('.scene-gallery')?.remove();
    dlcSections['all-scenes'].panel.querySelector('.scene-gallery')?.remove();
    dlcSections['all-scenes'].tab.hidden = true;
    dlcSections['all-scenes'].panel.hidden = true;
  }
  if (inAllScenes) renderSceneGallery(allScenesPanel);
  if (inAchievements) renderAchievements();
  if (inCharacters) renderCharacters();
  if (inDlc) renderDlc(dlcToActivate);
  if (dlc) renderDlcMenu(dlc, dlcSection);
  if (inCharacterStory) renderCharacterStoryMap(characterStoryId);
  if (inStoryMap) {
    renderLastDecision();
    renderStoryRewards();
  } else if (endingPreview.open && !(dlc && dlcSection === 'story-map')) {
    endingPreview.close();
  }

  const sectionTitle = (dlc ?? dlcToActivate)?.title ?? (inCharacterStory ? characterStoryTitle.textContent : highlightedTab?.textContent);
  document.title = sectionTitle ? `${sectionTitle} — День Серёжи — Minigames` : inGame ? 'День Серёжи — Minigames' : 'Minigames';
  const start = pendingStoryStart;
  pendingStoryStart = undefined;
  if (inGame && start) {
    const cafeteria = scenes[start.scene].cafeteria;
    startStory(start.scene, { phone: start.phone, lunch: start.lunch,
      lunchArrival: Boolean(start.lunch && cafeteria && cafeteria !== 'hall'), characterStory: start.characterStory });
    return;
  }

  activeCharacterStory = undefined;
  showScreen(dlc ? 'dlc-menu' : inGame ? 'menu' : highlightedTab ? 'details' : 'catalog', dlc, dlcSection);
  if (moveFocus) {
    const focusTarget = dlcToActivate ? '#dlc-list input[name="code"]'
      : dlc ? `#dlc-${dlcSection ?? 'menu'}-title` : inGame ? '#menu-title' : inCharacterStory ? '#character-story-title' : highlightedTab ? `${highlightedTab.hash}-title` : '#collection-title';
    document.querySelector(focusTarget).focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }
}

for (const [scene, button] of storyStarts) {
  button.addEventListener('click', () => openStoryAt({ scene }));
}
resumeButton.addEventListener('click', () => {
  if (lastDecision) openStoryAt(lastDecision);
});

for (const button of sceneBackButtons) button.addEventListener('click', goBackScene);

playButton.addEventListener('click', () => {
  if (hasGameAccess()) startStory('morning');
});
document.querySelector('#launch-blender').addEventListener('click', () => goToScene(activeScene.next));
document.querySelector('#blender-notification').addEventListener('click', () => goToScene(activeScene.next));
function showEndCard(scene) {
  updateSceneBack();
  const inDlc = activeCharacterStory?.dlc;
  const character = activeCharacterStory && !inDlc && characterStories[activeCharacterStory.id];
  const next = activeCharacterStory ? undefined : scene.afterEndCard;
  const artwork = character ? undefined : scene.endCardArt;
  ending.classList.toggle('is-art-only', Boolean(scene.artOnlyEndCard && artwork));
  endingArt.hidden = !artwork;
  if (artwork) endingArt.src = artPath(artwork);
  endingTitle.classList.toggle('ending-title-over-art', Boolean(artwork));
  endingTitle.textContent = character ? `Сюжет ${character.name} пройден` : scene.endCard ?? 'Soon ...';
  endingTitle.lang = character ? 'ru' : scene.endCardLang ?? 'en';
  endingNote.textContent = character ? '' : scene.endCardNote ?? '';
  endingNote.hidden = !endingNote.textContent;
  endingContinue.hidden = !next;
  endingContinue.dataset.next = next ?? '';
  endingMapLink.href = inDlc ? '#dlc' : character ? characterStoryHash(activeCharacterStory.id) : '#story-map';
  endingMapLink.textContent = inDlc ? 'К дополнениям' : character ? 'К карте персонажа' : 'Карта сюжета';
  if (next) preloadScene(next);
  showScreen('ending');
  if (scene.artOnlyEndCard) {
    endingTitle.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  } else {
    endingTitle.focus();
  }
}

endingContinue.addEventListener('click', () => renderScene(endingContinue.dataset.next));
function finishSceneSound() {
  if (activeScene?.waitForSound && !story.hidden) continueButton.disabled = false;
}

sceneAudio.addEventListener('ended', finishSceneSound);
sceneAudio.addEventListener('error', finishSceneSound);
continueButton.addEventListener('click', () => {
  if (activeScene.cafeteria === 'hall') {
    goToScene(lunchExitScene(activePosition.lunch));
    return;
  }
  if (activeScene.lunchAside) {
    goToScene(activeScene.next, { lunch: { ...activePosition.lunch, aside: null } });
    return;
  }
  if (activeScene.cafeteria) {
    const party = cafeteriaParties.find(({ id }) => id === activeScene.cafeteria);
    leaveLunchTable(party, activePosition.lunch);
    return;
  }
  if (activeScene.quiz) {
    advancePhoneRound();
    return;
  }
  if (activeScene.next) {
    if (activeScene.transition === 'ripple-collapse' && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const next = activeScene.next;
      continueButton.disabled = true;
      scenePicture.classList.add('is-ripple-collapse');
      sceneTimers.push(setTimeout(() => goToScene(next), 1250));
      return;
    }
    goToScene(activeScene.next, { remember: activeScene.ending !== 'time-loop' });
    return;
  }

  sceneHistory.push(activePosition);
  showEndCard(activeScene);
});
intertitleNext.addEventListener('click', () => goToScene(activeScene.next));
intertitleSound.addEventListener('click', () => {
  if (!intertitleAudio.paused) {
    intertitleAudio.pause();
    return;
  }

  intertitleStatus.textContent = '';
  intertitleAudio.currentTime = 0;
  intertitleAudio.play().catch((error) => {
    if (!intertitle.hidden && !story.hidden && error.name !== 'AbortError') {
      intertitleStatus.textContent = 'Озвучку не удалось воспроизвести.';
    }
  });
});
for (const event of ['play', 'pause', 'ended']) {
  intertitleAudio.addEventListener(event, () => {
    intertitleSound.setAttribute('aria-pressed', String(!intertitleAudio.paused && !intertitleAudio.ended));
  });
}
novel.addEventListener('click', (event) => {
  if (event.target.closest('a[href="#seryozha"]') && window.location.hash === '#seryozha') {
    event.preventDefault();
    syncRoute(true);
  }
});
document.querySelector('#close-ending-preview').addEventListener('click', () => endingPreview.close());
document.querySelector('#reset-characters').addEventListener('click', resetCharacters);
document.querySelector('#close-character-profile').addEventListener('click', () => characterProfile.close());
characterProfileBody.addEventListener('animationstart', (event) => {
  if (event.animationName !== 'character-mask-out' || !characterProfile.open || !characterProfileBody.contains(event.target)) return;
  characterRevealAudio.currentTime = 0;
  characterRevealAudio.play().catch(() => {});
});
characterProfile.addEventListener('close', () => {
  characterRevealAudio.pause();
  if (activeProfile === 'yana' || (activeProfile === 'diana' && !encounteredCharacters().has('yana'))) {
    profileQueue.unshift({ id: 'seryozha', reveal: true });
  }
  activeProfile = undefined;
  showNextCharacterProfile();
});
endingPreview.addEventListener('click', (event) => {
  if (event.target === endingPreview) endingPreview.close();
});
for (const trigger of document.querySelectorAll('[data-open-settings]')) {
  trigger.addEventListener('click', () => settingsDialog.showModal());
}

function getDlcSceneKeys(dlc) {
  const visited = new Set();
  const pending = (dlc.roadmap ?? []).map(({ scene }) => scene).reverse();
  while (pending.length) {
    const key = pending.pop();
    if (!key || visited.has(key) || !Object.hasOwn(scenes, key)) continue;
    visited.add(key);
    const { next, afterEndCard, options = [] } = scenes[key];
    pending.push(afterEndCard, ...options.map(([, target]) => target).reverse(), next);
  }
  return visited;
}

const dlcSceneKeys = new Map(downloadableStories.map((dlc) => [dlc.character, getDlcSceneKeys(dlc)]));
const allDlcSceneKeys = new Set([...dlcSceneKeys.values()].flatMap((keys) => [...keys]));

function renderSceneGallery(panel, dlc) {
  const chapter = dlc?.character ?? '';
  const previous = panel.querySelector('.scene-gallery');
  if (previous?.dataset.chapter === chapter) return;
  previous?.remove();

  const gallery = sceneGalleryTemplate.content.firstElementChild.cloneNode(true);
  gallery.dataset.chapter = chapter;
  const search = gallery.querySelector('input');
  const status = gallery.querySelector('[role="status"]');
  const list = gallery.querySelector('ul');
  const keys = dlc ? dlcSceneKeys.get(chapter) : Object.keys(scenes).filter((key) => !allDlcSceneKeys.has(key));
  const entries = Array.from(keys, (key) => {
    const scene = scenes[key];
    const title = scene.title ?? scene.endCard ?? key;
    const image = scene.endCardArt ?? scene.art;
    const item = document.createElement('li');
    const button = document.createElement('button');
    button.className = 'story-point scene-gallery-card';
    button.type = 'button';
    const thumbnail = document.createElement('span');
    thumbnail.className = 'scene-gallery-thumbnail';
    if (scene.poster || image) {
      const img = document.createElement('img');
      img.src = scene.poster ?? artPath(image);
      img.alt = '';
      img.loading = 'lazy';
      img.decoding = 'async';
      thumbnail.append(img);
    } else {
      thumbnail.textContent = 'Без иллюстрации';
    }
    const caption = document.createElement('strong');
    caption.textContent = title;
    button.dataset.scene = key;
    button.append(thumbnail, caption);
    button.addEventListener('click', () => {
      if (!developerMode) return;
      if (dlc) playDlc(dlc, key);
      else openStoryAt({ scene: key });
    });
    item.append(button);
    return { item, searchText: `${title} ${key}`.toLowerCase() };
  });
  list.append(...entries.map(({ item }) => item));
  search.addEventListener('input', () => {
    const query = search.value.trim().toLowerCase();
    let found = false;
    for (const { item, searchText } of entries) {
      item.hidden = !searchText.includes(query);
      found ||= !item.hidden;
    }
    status.hidden = found;
    status.textContent = found ? '' : 'Сцены не найдены.';
  });
  panel.append(gallery);
}

function setDeveloperMode(enabled) {
  developerMode = enabled;
  developerAccessForm.hidden = enabled;
  developerActions.hidden = !enabled;
  developerUnlock.checked = false;
  developerUnlockCharacters.checked = false;
  developerSaveAchievements.checked = false;
  if (!enabled || (story.hidden && ending.hidden)) syncRoute();
  else if (!story.hidden) showCharacterEncounters(activePosition.key, activeScene.meet);
}

developerCode.addEventListener('input', () => {
  developerCode.removeAttribute('aria-invalid');
  developerCodeStatus.textContent = '';
});

developerAccessForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = developerAccessForm.querySelector('button');
  if (submit.disabled) return;
  submit.disabled = true;
  developerCode.readOnly = true;
  try {
    if (!/^[A-Fa-f0-9]{64}$/.test(developerCode.value) || !await matchesAccessCode(developerCode.value, developerCodeHash)) {
      developerCode.setAttribute('aria-invalid', 'true');
      developerCodeStatus.textContent = 'Неверный код администратора.';
      developerCode.focus();
      return;
    }
    developerAccessForm.reset();
    developerCodeStatus.textContent = '';
    setDeveloperMode(true);
    if (settingsDialog.open) developerUnlock.focus();
  } catch {
    developerCodeStatus.textContent = 'Проверка кода недоступна. Открой сайт через HTTPS или localhost.';
  } finally {
    submit.disabled = false;
    developerCode.readOnly = false;
  }
});

developerUnlock.addEventListener('change', () => {
  if (developerMode && story.hidden && ending.hidden) syncRoute();
});
developerUnlockCharacters.addEventListener('change', () => {
  if (developerMode && !charactersPanel.hidden) renderCharacters();
});
document.querySelector('#developer-exit').addEventListener('click', () => {
  setDeveloperMode(false);
  developerTools.querySelector('summary').focus();
});
document.querySelector('#developer-open-map').addEventListener('click', () => {
  if (!developerMode) return;
  settingsDialog.close();
  const character = activeCharacterStory?.dlc
    ? activeCharacterStory.id
    : window.location.hash.match(/^#dlc\/([^/]+)/)?.[1];
  const hash = character ? dlcMenuHash(character, 'all-scenes') : '#all-scenes';
  if (window.location.hash === hash) document.querySelector(`${character ? '#dlc-all-scenes-panel' : '#all-scenes-panel'} input`).focus();
  else window.location.hash = hash;
});

document.querySelector('#close-settings').addEventListener('click', () => settingsDialog.close());
settingsDialog.addEventListener('close', () => showProgressResetConfirmation(false));
muteSound.addEventListener('change', () => {
  applySoundSetting(muteSound.checked);
  try {
    localStorage.setItem(mutedSoundStorageKey, muteSound.checked ? '1' : '0');
  } catch {
    // Sound can still be changed for the current visit.
  }
});
requestProgressReset.addEventListener('click', () => {
  showProgressResetConfirmation(true);
  cancelProgressReset.focus();
});
cancelProgressReset.addEventListener('click', () => {
  showProgressResetConfirmation(false);
  requestProgressReset.focus();
});
document.querySelector('#confirm-progress-reset').addEventListener('click', resetProgress);
window.addEventListener('hashchange', () => syncRoute(true));
window.addEventListener('storage', (event) => {
  if (event.key === mutedSoundStorageKey) {
    applySoundSetting(event.newValue === '1');
    return;
  }
  if (event.key === progressResetStorageKey) {
    restartAtCatalog();
    return;
  }
  if (event.key === dianaAliasStorageKey) {
    dianaAlias = event.newValue;
  } else if (event.key?.startsWith(characterStoragePrefix)) {
    const id = event.key.slice(characterStoragePrefix.length);
    if (!Object.hasOwn(characters, id)) return;
    if (event.newValue === '1') discoveredCharacters.add(id);
    else discoveredCharacters.delete(id);
    if (!charactersPanel.hidden) renderCharacters();
    const openDlc = !dlcMenuPanel.hidden && window.location.hash.split('/')[1] === id;
    if (openDlc && !hasDlcAccess(id)) syncRoute(true);
    else if (!dlcPanel.hidden) {
      if (window.location.hash === '#dlc') renderDlc();
      else if (window.location.hash === dlcMenuHash(id)) syncRoute(true);
    }
    else if (event.newValue !== '1' && !characterStoryPanel.hidden && window.location.hash === characterStoryHash(id)) syncRoute(true);
  }
  if (event.newValue === '1' && event.key === dlcStoragePrefix + window.location.hash.split('/')[1] && !dlcPanel.hidden) {
    syncRoute();
  }
  const rewardChanged = event.key === endingsStorageKey || achievements.some(({ id }) => event.key === gameStoragePrefix + id);
  const dlcRewardChanged = downloadableStories.some(({ achievements: results = [] }) =>
    results.some(({ id }) => event.key === gameStoragePrefix + id));
  if ((rewardChanged || dlcRewardChanged) && !achievementsPanel.hidden) renderAchievements();
  if (rewardChanged && !storyMapPanel.hidden && !endingPreview.open) renderStoryRewards();
  if (dlcRewardChanged && !dlcMenuPanel.hidden && dlcOverview.hidden) syncRoute();
  if (!storyMapPanel.hidden && event.key === decisionStorageKey) {
    renderLastDecision();
    renderStoryStarts();
  }
  if (event.key?.startsWith(storyStartStoragePrefix)) renderStoryStarts();
});
try {
  applySoundSetting(localStorage.getItem(mutedSoundStorageKey) === '1');
} catch {
  // The default sound setting remains available without storage.
}
syncRoute();
